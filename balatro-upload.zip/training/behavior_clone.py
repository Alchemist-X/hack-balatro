"""Behavior cloning (BC) pre-training for the Balatro agent.

Uses trajectories collected from the rule-based agent to initialise
the policy network via supervised learning, so that subsequent PPO
training starts from a reasonable policy rather than random.
"""

from __future__ import annotations

from pathlib import Path

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm

from agents.ppo_agent import PPOAgent


class BehaviorCloner:
    """Supervised pre-training of the policy network on expert trajectories.

    Parameters
    ----------
    agent : PPOAgent
        The agent whose policy network will be trained.
    lr : float
        Learning rate for BC.
    batch_size : int
        Mini-batch size.
    num_epochs : int
        Number of passes over the dataset.
    device : str or torch.device
        Device to train on.
    """

    def __init__(
        self,
        agent: PPOAgent,
        lr: float = 1e-3,
        batch_size: int = 256,
        num_epochs: int = 50,
        device: str | torch.device = "auto",
    ):
        self.agent = agent
        self.lr = lr
        self.batch_size = batch_size
        self.num_epochs = num_epochs

        if device == "auto":
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)

    def load_trajectories(self, path: str | Path) -> tuple[torch.Tensor, torch.Tensor]:
        """Load trajectory data from a ``.pt`` file.

        Expected format: dict with keys ``observations`` (N, obs_dim)
        and ``actions`` (N,).

        Returns
        -------
        obs : Tensor (N, obs_dim)
        actions : Tensor (N,) long
        """
        data = torch.load(path, map_location="cpu", weights_only=True)
        obs = data["observations"].float()
        actions = data["actions"].long()
        return obs, actions

    def train(self, trajectory_path: str | Path) -> dict[str, float]:
        """Run behavior cloning training.

        Parameters
        ----------
        trajectory_path : str or Path
            Path to the trajectory ``.pt`` file.

        Returns
        -------
        dict with final metrics: loss, accuracy
        """
        obs, actions = self.load_trajectories(trajectory_path)
        dataset = TensorDataset(obs, actions)
        loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)

        self.agent.model.to(self.device)
        self.agent.model.train()

        optimizer = optim.Adam(self.agent.parameters, lr=self.lr)
        criterion = nn.CrossEntropyLoss()

        best_loss = float("inf")

        for epoch in range(self.num_epochs):
            epoch_loss = 0.0
            epoch_correct = 0
            epoch_total = 0

            for batch_obs, batch_actions in loader:
                batch_obs = batch_obs.to(self.device)
                batch_actions = batch_actions.to(self.device)

                # Forward pass through the agent's evaluate-like path
                tensors = self.agent._obs_batch_to_tensors(batch_obs)
                out = self.agent.model(**tensors)
                logits = out["intent_logits"]

                # Clamp actions to valid range
                num_classes = logits.shape[-1]
                batch_actions = batch_actions.clamp(0, num_classes - 1)

                loss = criterion(logits, batch_actions)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                epoch_loss += loss.item() * batch_obs.shape[0]
                preds = logits.argmax(dim=-1)
                epoch_correct += (preds == batch_actions).sum().item()
                epoch_total += batch_obs.shape[0]

            avg_loss = epoch_loss / max(epoch_total, 1)
            accuracy = epoch_correct / max(epoch_total, 1)

            if avg_loss < best_loss:
                best_loss = avg_loss

            if (epoch + 1) % 10 == 0:
                print(
                    f"  BC Epoch {epoch + 1}/{self.num_epochs} | "
                    f"Loss: {avg_loss:.4f} | Acc: {accuracy:.3f}"
                )

        return {
            "final_loss": best_loss,
            "final_accuracy": accuracy,
        }
