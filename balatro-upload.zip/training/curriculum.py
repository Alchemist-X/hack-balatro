"""Curriculum learning scheduler for progressively harder Balatro training.

Manages a sequence of difficulty levels.  The agent advances to the
next level once it achieves a target win-rate on the current level
over a minimum number of evaluation episodes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class CurriculumLevel:
    """Definition of a single curriculum level."""
    name: str
    max_ante: int = 8
    min_win_rate: float = 0.5
    min_episodes: int = 5000
    extra_config: dict = field(default_factory=dict)


class CurriculumScheduler:
    """Tracks curriculum progress and determines when to advance.

    Parameters
    ----------
    levels : list of CurriculumLevel
        Ordered difficulty levels from easiest to hardest.
    """

    def __init__(self, levels: list[CurriculumLevel] | None = None):
        if levels is None:
            levels = self._default_levels()
        self.levels = levels
        self._current_idx = 0
        self._episode_count = 0
        self._recent_wins = 0
        self._recent_episodes = 0
        self._history: list[dict] = []

    @property
    def current_level(self) -> CurriculumLevel:
        return self.levels[self._current_idx]

    @property
    def current_level_name(self) -> str:
        return self.current_level.name

    @property
    def is_final_level(self) -> bool:
        return self._current_idx >= len(self.levels) - 1

    @property
    def level_index(self) -> int:
        return self._current_idx

    def get_env_config_overrides(self) -> dict:
        """Return environment config overrides for the current level."""
        level = self.current_level
        overrides = {
            "game": {
                "max_ante": level.max_ante,
            },
        }
        overrides.update(level.extra_config)
        return overrides

    def report_episode(self, won: bool):
        """Report the outcome of one episode.

        Parameters
        ----------
        won : bool
            Whether the agent won (completed the run).
        """
        self._episode_count += 1
        self._recent_episodes += 1
        if won:
            self._recent_wins += 1

    def should_advance(self) -> bool:
        """Check if the agent should advance to the next curriculum level."""
        if self.is_final_level:
            return False

        level = self.current_level

        if self._recent_episodes < level.min_episodes:
            return False

        win_rate = self._recent_wins / max(self._recent_episodes, 1)
        return win_rate >= level.min_win_rate

    def advance(self) -> bool:
        """Advance to the next curriculum level if conditions are met.

        Returns
        -------
        bool : True if advanced, False if already at final level.
        """
        if not self.should_advance():
            return False

        win_rate = self._recent_wins / max(self._recent_episodes, 1)

        self._history.append({
            "level": self.current_level.name,
            "episodes": self._recent_episodes,
            "win_rate": win_rate,
        })

        self._current_idx += 1
        self._recent_wins = 0
        self._recent_episodes = 0

        print(
            f"  Curriculum: advanced to level "
            f"'{self.current_level.name}' "
            f"(prev win_rate={win_rate:.3f})"
        )
        return True

    def get_summary(self) -> dict:
        """Return a summary of curriculum progress."""
        win_rate = (
            self._recent_wins / max(self._recent_episodes, 1)
            if self._recent_episodes > 0
            else 0.0
        )
        return {
            "current_level": self.current_level.name,
            "level_index": self._current_idx,
            "total_levels": len(self.levels),
            "episodes_this_level": self._recent_episodes,
            "win_rate_this_level": win_rate,
            "total_episodes": self._episode_count,
            "history": self._history,
        }

    # ------------------------------------------------------------------

    @staticmethod
    def _default_levels() -> list[CurriculumLevel]:
        return [
            CurriculumLevel(
                name="easy",
                max_ante=4,
                min_win_rate=0.6,
                min_episodes=5000,
            ),
            CurriculumLevel(
                name="standard",
                max_ante=8,
                min_win_rate=0.4,
                min_episodes=10000,
            ),
            CurriculumLevel(
                name="hard",
                max_ante=8,
                min_win_rate=0.3,
                min_episodes=20000,
            ),
        ]

    @classmethod
    def from_config(cls, config: dict) -> CurriculumScheduler:
        """Create a scheduler from a training config dict."""
        levels_cfg = config.get("curriculum", {}).get("levels", [])
        levels = []
        for lc in levels_cfg:
            levels.append(CurriculumLevel(
                name=lc["name"],
                max_ante=lc.get("max_ante", 8),
                min_win_rate=lc.get("min_win_rate", 0.5),
                min_episodes=lc.get("min_episodes", 5000),
                extra_config=lc.get("extra_config", {}),
            ))
        if not levels:
            return cls()  # Use defaults
        return cls(levels=levels)
