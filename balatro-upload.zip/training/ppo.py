"""Proximal Policy Optimization (PPO) trainer for the Balatro agent.

Implements the clipped surrogate objective with GAE, value function
loss, and entropy regularisation. Supports action masking.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.optim as optim

from agents.ppo_agent import PPOAgent
from training.rollout import RolloutBuffer


@dataclass
class PPOConfig:
    """PPO hyperparameters."""
    clip_range: float = 0.2
    clip_range_vf: float | None = None
    entropy_coef: float = 0.01
    value_loss_coef: float = 0.5
    max_grad_norm: float = 0.5
    num_epochs: int = 4
    mini_batch_size: int = 256

    lr: float = 3e-4
    eps: float = 1e-5
    weight_decay: float = 0.0

    scheduler_type: str = "cosine"
    warmup_steps: int = 0
    total_optimizer_steps: int = 100_000


class PPOTrainer:
    """Manages PPO training: loss computation, optimisation, and LR scheduling."""

    def __init__(self, agent: PPOAgent, config: PPOConfig | None = None):
        self.agent = agent
        self.config = config or PPOConfig()

        self.optimizer = optim.Adam(
            agent.parameters,
            lr=self.config.lr,
            eps=self.config.eps,
            weight_decay=self.config.weight_decay,
        )

        if self.config.scheduler_type == "cosine" and self.config.total_optimizer_steps > 0:
            self.scheduler = optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer,
                T_max=max(self.config.total_optimizer_steps, 1),
            )
        else:
            self.scheduler = None

        self._update_count = 0

    def update(self, buffer: RolloutBuffer) -> dict[str, float]:
        """Run one PPO update using data from the rollout buffer."""
        cfg = self.config
        total_policy_loss = 0.0
        total_value_loss = 0.0
        total_entropy_loss = 0.0
        total_loss = 0.0
        num_updates = 0

        for epoch in range(cfg.num_epochs):
            batches = buffer.get_batches(cfg.mini_batch_size)
            for batch in batches:
                metrics = self._update_step(batch)
                total_policy_loss += metrics["policy_loss"]
                total_value_loss += metrics["value_loss"]
                total_entropy_loss += metrics["entropy"]
                total_loss += metrics["total_loss"]
                num_updates += 1

        self._update_count += 1

        return {
            "policy_loss": total_policy_loss / max(num_updates, 1),
            "value_loss": total_value_loss / max(num_updates, 1),
            "entropy": total_entropy_loss / max(num_updates, 1),
            "total_loss": total_loss / max(num_updates, 1),
            "learning_rate": self.optimizer.param_groups[0]["lr"],
            "update_count": self._update_count,
        }

    def _update_step(self, batch: dict[str, torch.Tensor]) -> dict[str, float]:
        """Single gradient step on one mini-batch."""
        cfg = self.config
        obs = batch["obs"]
        actions = batch["actions"]
        old_log_probs = batch["old_log_probs"]
        advantages = batch["advantages"]
        returns = batch["returns"]
        old_values = batch["old_values"]
        masks = batch.get("masks", None)

        # Forward pass (with action masks)
        log_probs, values, entropy = self.agent.evaluate(obs, actions, mask_batch=masks)

        # Policy loss (clipped surrogate)
        ratio = torch.exp(log_probs - old_log_probs)
        surr1 = ratio * advantages
        surr2 = torch.clamp(ratio, 1.0 - cfg.clip_range, 1.0 + cfg.clip_range) * advantages
        policy_loss = -torch.min(surr1, surr2).mean()

        # Value loss
        if cfg.clip_range_vf is not None:
            values_clipped = old_values + torch.clamp(
                values - old_values, -cfg.clip_range_vf, cfg.clip_range_vf
            )
            vf_loss1 = (values - returns) ** 2
            vf_loss2 = (values_clipped - returns) ** 2
            value_loss = 0.5 * torch.max(vf_loss1, vf_loss2).mean()
        else:
            value_loss = 0.5 * ((values - returns) ** 2).mean()

        # Entropy bonus
        entropy_loss = entropy.mean()

        # Total loss
        loss = (
            policy_loss
            + cfg.value_loss_coef * value_loss
            - cfg.entropy_coef * entropy_loss
        )

        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.agent.parameters, cfg.max_grad_norm)
        self.optimizer.step()

        if self.scheduler is not None:
            self.scheduler.step()

        return {
            "policy_loss": policy_loss.item(),
            "value_loss": value_loss.item(),
            "entropy": entropy_loss.item(),
            "total_loss": loss.item(),
        }

    def state_dict(self) -> dict:
        return {
            "optimizer": self.optimizer.state_dict(),
            "scheduler": self.scheduler.state_dict() if self.scheduler else None,
            "update_count": self._update_count,
        }

    def load_state_dict(self, state: dict):
        self.optimizer.load_state_dict(state["optimizer"])
        if self.scheduler and state.get("scheduler"):
            self.scheduler.load_state_dict(state["scheduler"])
        self._update_count = state.get("update_count", 0)
