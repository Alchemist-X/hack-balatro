"""Rollout buffer for collecting trajectories from parallel environments.

Stores transitions (obs, action, reward, value, log_prob, done) and
computes GAE (Generalized Advantage Estimation) returns for PPO updates.
"""

from __future__ import annotations

import numpy as np
import torch

from env.action_decoder import ACTION_SPACE_SIZE


class RolloutBuffer:
    """Fixed-size buffer for one rollout across parallel environments.

    Parameters
    ----------
    obs_dim : int
        Dimension of the encoded observation vector.
    steps_per_env : int
        Number of steps collected per environment per rollout.
    num_envs : int
        Number of parallel environments.
    gamma : float
        Discount factor.
    gae_lambda : float
        GAE lambda.
    device : torch.device
        Device for yielded batches.
    """

    def __init__(
        self,
        obs_dim: int,
        steps_per_env: int = 128,
        num_envs: int = 16,
        gamma: float = 0.99,
        gae_lambda: float = 0.95,
        device: torch.device | str = "cpu",
    ):
        self.obs_dim = obs_dim
        self.steps_per_env = steps_per_env
        self.num_envs = num_envs
        self.gamma = gamma
        self.gae_lambda = gae_lambda
        self.device = torch.device(device)
        self.total_size = steps_per_env * num_envs

        # Pre-allocate
        self.observations = np.zeros((steps_per_env, num_envs, obs_dim), dtype=np.float32)
        self.actions = np.zeros((steps_per_env, num_envs), dtype=np.int64)
        self.rewards = np.zeros((steps_per_env, num_envs), dtype=np.float32)
        self.dones = np.zeros((steps_per_env, num_envs), dtype=np.float32)
        self.values = np.zeros((steps_per_env, num_envs), dtype=np.float32)
        self.log_probs = np.zeros((steps_per_env, num_envs), dtype=np.float32)

        # Computed after rollout
        self.advantages = np.zeros((steps_per_env, num_envs), dtype=np.float32)
        self.returns = np.zeros((steps_per_env, num_envs), dtype=np.float32)

        self._step = 0

    def reset(self):
        self._step = 0

    def add(self, obs, action, reward, done, value, log_prob):
        """Add one timestep of transitions from all parallel envs."""
        assert self._step < self.steps_per_env, "Buffer is full"
        self.observations[self._step] = obs
        self.actions[self._step] = action
        self.rewards[self._step] = reward
        self.dones[self._step] = done
        self.values[self._step] = value
        self.log_probs[self._step] = log_prob
        self._step += 1

    def compute_returns(self, last_values: np.ndarray):
        """Compute GAE advantages and discounted returns."""
        T = self.steps_per_env
        last_gae = np.zeros(self.num_envs, dtype=np.float32)

        for t in reversed(range(T)):
            if t == T - 1:
                next_non_terminal = 1.0 - self.dones[t]
                next_values = last_values
            else:
                next_non_terminal = 1.0 - self.dones[t]
                next_values = self.values[t + 1]

            delta = (
                self.rewards[t]
                + self.gamma * next_values * next_non_terminal
                - self.values[t]
            )
            last_gae = delta + self.gamma * self.gae_lambda * next_non_terminal * last_gae
            self.advantages[t] = last_gae

        self.returns = self.advantages + self.values

    def get_batches(self, batch_size: int) -> list[dict[str, torch.Tensor]]:
        """Yield mini-batches of the entire rollout buffer."""
        flat_obs = self.observations.reshape(self.total_size, self.obs_dim)
        flat_actions = self.actions.reshape(self.total_size)
        flat_log_probs = self.log_probs.reshape(self.total_size)
        flat_advantages = self.advantages.reshape(self.total_size)
        flat_returns = self.returns.reshape(self.total_size)
        flat_values = self.values.reshape(self.total_size)

        # Normalize advantages
        adv_mean = flat_advantages.mean()
        adv_std = flat_advantages.std() + 1e-8
        flat_advantages = (flat_advantages - adv_mean) / adv_std

        indices = np.random.permutation(self.total_size)

        batches = []
        for start in range(0, self.total_size, batch_size):
            end = min(start + batch_size, self.total_size)
            idx = indices[start:end]

            # Extract action masks from observations (first 79 dims)
            obs_slice = flat_obs[idx]
            masks = obs_slice[:, :ACTION_SPACE_SIZE] > 0.5  # action mask is first 79 dims

            batches.append({
                "obs": torch.tensor(obs_slice, device=self.device),
                "actions": torch.tensor(flat_actions[idx], dtype=torch.long, device=self.device),
                "old_log_probs": torch.tensor(flat_log_probs[idx], device=self.device),
                "advantages": torch.tensor(flat_advantages[idx], device=self.device),
                "returns": torch.tensor(flat_returns[idx], device=self.device),
                "old_values": torch.tensor(flat_values[idx], device=self.device),
                "masks": torch.tensor(masks, dtype=torch.bool, device=self.device),
            })

        return batches
