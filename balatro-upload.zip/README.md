# hack-balatro

Superhuman Balatro AI Agent via Reinforcement Learning.

## Goal

Train an RL agent that achieves superhuman win-rate and win-streak in the poker roguelike deck-builder [Balatro](https://www.playbalatro.com/).

## Key References

| Repo | Role |
|------|------|
| [cassiusfive/balatro-gym](https://github.com/cassiusfive/balatro-gym) | Primary Gymnasium environment |
| [evanofslack/balatro-rs](https://github.com/evanofslack/balatro-rs) | High-perf Rust engine (future backend) |
| [coder/balatrobot](https://github.com/coder/balatrobot) | JSON-RPC API to real game |
| [vivasvan1/balatro-dqn-agent](https://github.com/vivasvan1/balatro-dqn-agent) | DQN training reference |
| [xwkya/RLatro](https://github.com/xwkya/RLatro) | Deterministic headless simulator |

## Project Structure

```
hack-balatro/
  configs/          # Environment, model, training, and cloud configs
  env/              # Balatro environment wrappers and state/action encoding
  models/           # Neural network modules (Transformer encoders, policy/value heads)
  agents/           # Agent implementations (random, rule-based, PPO, MCTS)
  training/         # RL training pipeline (PPO, behavior cloning, curriculum)
  eval/             # Evaluation scripts and fixed seed test sets
  scripts/          # Entry-point scripts for training and evaluation
  docs/             # Architecture docs and roadmap
```

## Quick Start

```bash
# Create virtual environment
python -m venv .venv && source .venv/bin/activate

# Install dependencies
pip install -e .

# Run random agent to verify environment
python scripts/eval_run.py --agent random --episodes 100

# Train PPO agent
python scripts/train_ppo.py --config configs/train.yaml

# Evaluate trained agent
python scripts/eval_run.py --agent ppo --checkpoint checkpoints/best.pt
```

## Training Phases

1. **Phase 0** - Project init and dependencies
2. **Phase 1** - Environment wrapping and validation
3. **Phase 2** - Baseline agents (random + rule-based)
4. **Phase 3** - Neural network model (Transformer + MLP)
5. **Phase 4** - PPO training pipeline
6. **Phase 5** - Behavior cloning + curriculum learning
7. **Phase 6** - MCTS search augmentation
8. **Phase 7** - Superhuman evaluation and benchmarking

## License

MIT
