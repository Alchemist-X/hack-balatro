"""Rule-based heuristic agent for Balatro.

Implements a hand-coded strategy that serves as a strong baseline and
as a source of trajectory data for behavior cloning.

Strategy summary
----------------
- **Play phase**: always play the highest-scoring valid poker hand.
  Priority: straight flush > four of a kind > full house > flush >
  straight > three of a kind > two pair > pair > high card.
- **Discard phase**: discard lowest-value cards that don't contribute
  to the best available hand type.
- **Shop phase**: buy high-value Jokers when affordable; skip otherwise.
- **Blind select**: always accept the blind (no skipping).
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations
from typing import Any

import numpy as np


# ── Poker hand evaluation (simplified) ────────────────────────────────

# Hand type priorities (higher = better)
HAND_PRIORITIES = {
    "straight_flush": 9,
    "four_of_a_kind": 8,
    "full_house": 7,
    "flush": 6,
    "straight": 5,
    "three_of_a_kind": 4,
    "two_pair": 3,
    "pair": 2,
    "high_card": 1,
}


def classify_hand(ranks: list[int], suits: list[str]) -> tuple[str, int]:
    """Classify a poker hand and return (hand_type, base_score).

    Parameters
    ----------
    ranks : list of int (2-14, Ace=14)
    suits : list of str

    Returns
    -------
    (hand_type, base_score)
    """
    n = len(ranks)
    if n == 0:
        return ("high_card", 0)

    rank_counts = Counter(ranks)
    suit_counts = Counter(suits)
    sorted_ranks = sorted(ranks)

    is_flush = n >= 5 and max(suit_counts.values()) >= 5
    is_straight = _is_straight(sorted_ranks)

    if is_flush and is_straight and n >= 5:
        return ("straight_flush", 100 + max(ranks))
    if 4 in rank_counts.values():
        quad_rank = [r for r, c in rank_counts.items() if c == 4][0]
        return ("four_of_a_kind", 80 + quad_rank)
    if 3 in rank_counts.values() and 2 in rank_counts.values():
        trip_rank = [r for r, c in rank_counts.items() if c == 3][0]
        return ("full_house", 70 + trip_rank)
    if is_flush:
        return ("flush", 60 + max(ranks))
    if is_straight:
        return ("straight", 50 + max(ranks))
    if 3 in rank_counts.values():
        trip_rank = [r for r, c in rank_counts.items() if c == 3][0]
        return ("three_of_a_kind", 40 + trip_rank)
    pairs = [r for r, c in rank_counts.items() if c == 2]
    if len(pairs) >= 2:
        return ("two_pair", 30 + max(pairs))
    if len(pairs) == 1:
        return ("pair", 20 + pairs[0])
    return ("high_card", max(ranks))


def _is_straight(sorted_ranks: list[int]) -> bool:
    if len(sorted_ranks) < 5:
        return False
    # Check consecutive
    unique = sorted(set(sorted_ranks))
    for i in range(len(unique) - 4):
        if unique[i + 4] - unique[i] == 4:
            return True
    # Check ace-low straight (A-2-3-4-5)
    if set([14, 2, 3, 4, 5]).issubset(set(sorted_ranks)):
        return True
    return False


# ── Rule-based agent ──────────────────────────────────────────────────

class RuleBasedAgent:
    """Heuristic agent that follows fixed rules.

    Works with either raw dict observations or the simplified
    integer-action interface of BalatroEnvWrapper.
    """

    def __init__(self, seed: int | None = None):
        self.rng = np.random.default_rng(seed)
        self.name = "RuleBasedAgent"
        # Trajectory recording
        self.trajectory: list[dict] = []
        self._recording = False

    def start_recording(self):
        self.trajectory = []
        self._recording = True

    def stop_recording(self) -> list[dict]:
        self._recording = False
        return self.trajectory

    def reset(self):
        pass

    # ------------------------------------------------------------------
    # Main decision
    # ------------------------------------------------------------------

    def act(
        self,
        obs: np.ndarray,
        info: dict | None = None,
        action_mask: np.ndarray | None = None,
    ) -> int:
        """Choose an action index based on heuristic rules.

        If ``info`` contains structured game data (hand, phase, etc.)
        the agent uses it for smarter decisions.  Otherwise it falls
        back to picking the first valid action.
        """
        info = info or {}
        phase = info.get("phase", "play")

        if phase == "play":
            action = self._play_phase(info, action_mask)
        elif phase == "discard":
            action = self._discard_phase(info, action_mask)
        elif phase == "shop":
            action = self._shop_phase(info, action_mask)
        elif phase == "blind_select":
            action = self._blind_select_phase(info, action_mask)
        else:
            action = self._fallback(action_mask)

        # Record trajectory
        if self._recording:
            self.trajectory.append({
                "obs": obs.copy() if isinstance(obs, np.ndarray) else obs,
                "action": action,
                "phase": phase,
                "info": {k: v for k, v in info.items() if k != "raw_obs"},
            })

        return action

    # ------------------------------------------------------------------
    # Phase strategies
    # ------------------------------------------------------------------

    def _play_phase(self, info: dict, mask: np.ndarray | None) -> int:
        """Pick the best poker hand from available play actions."""
        hand = info.get("hand", [])
        valid_actions = info.get("valid_actions", {})

        # If structured play actions available, evaluate each
        if isinstance(valid_actions, dict) and "play" in valid_actions:
            play_actions = valid_actions["play"]
            best_idx = 0
            best_score = -1
            for i, action in enumerate(play_actions):
                cards = action.get("cards", [])
                if not cards or not hand:
                    continue
                ranks = []
                suits = []
                for c_idx in cards:
                    if c_idx < len(hand):
                        card = hand[c_idx]
                        ranks.append(card.get("rank", 2))
                        suits.append(card.get("suit", ""))
                _, score = classify_hand(ranks, suits)
                if score > best_score:
                    best_score = score
                    best_idx = i
            return best_idx

        # Fallback: first valid action
        return self._fallback(mask)

    def _discard_phase(self, info: dict, mask: np.ndarray | None) -> int:
        """Discard the lowest-value cards."""
        # Simple heuristic: pick the discard action that removes lowest cards
        # With limited info, just pick first valid discard
        return self._fallback(mask)

    def _shop_phase(self, info: dict, mask: np.ndarray | None) -> int:
        """Buy high-value items or skip."""
        money = info.get("money", 0)
        shop_items = info.get("shop_items", [])

        # If we can afford something, buy the first item
        for i, item in enumerate(shop_items):
            cost = item.get("cost", 999)
            if cost <= money:
                return i  # Buy this item

        # Otherwise skip (usually the last valid action)
        if mask is not None:
            valid = np.where(mask)[0]
            if len(valid) > 0:
                return int(valid[-1])  # Skip is typically last
        return 0

    def _blind_select_phase(self, info: dict, mask: np.ndarray | None) -> int:
        """Always accept the blind."""
        return 0  # Select blind (first action)

    @staticmethod
    def _fallback(mask: np.ndarray | None) -> int:
        """Pick the first valid action."""
        if mask is not None:
            valid = np.where(mask)[0]
            if len(valid) > 0:
                return int(valid[0])
        return 0
