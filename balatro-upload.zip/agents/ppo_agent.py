"""PPO Agent adapted for the pylatro-based Balatro environment.

Uses a simple MLP policy-value network that takes the 98-dim observation
(action_mask + stage_onehot + scalar_features) and outputs:
  - action logits over the 79-dim action space
  - a scalar value estimate V(s)
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from env.state_encoder import OBS_DIM, ACTION_MASK_SIZE
from env.action_decoder import ACTION_SPACE_SIZE


class BalatroMLP(nn.Module):
    """Simple MLP policy-value network for the Balatro agent.

    Input: 98-dim observation
    Output: 79-dim action logits + scalar value
    """

    def __init__(self, obs_dim: int = OBS_DIM, action_dim: int = ACTION_SPACE_SIZE, hidden_dim: int = 256):
        super().__init__()

        # Shared feature extractor
        self.shared = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )

        # Policy head
        self.policy_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
        )

        # Value head
        self.value_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(self, obs: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Forward pass.

        Parameters
        ----------
        obs : (B, obs_dim)

        Returns
        -------
        action_logits : (B, action_dim)
        value : (B,)
        """
        features = self.shared(obs)
        logits = self.policy_head(features)
        value = self.value_head(features).squeeze(-1)
        return logits, value


class PPOAgent:
    """PPO-based Balatro agent with masked action support.

    Uses a flat MLP that takes the 98-dim encoded observation and
    produces action logits masked by the action mask from pylatro.
    """

    def __init__(
        self,
        obs_dim: int = OBS_DIM,
        action_dim: int = ACTION_SPACE_SIZE,
        hidden_dim: int = 256,
        device: str = "auto",
    ):
        self.name = "PPOAgent"
        self.obs_dim = obs_dim
        self.action_dim = action_dim

        if device == "auto":
            if torch.cuda.is_available():
                self.device = torch.device("cuda")
            elif torch.backends.mps.is_available():
                self.device = torch.device("mps")
            else:
                self.device = torch.device("cpu")
        else:
            self.device = torch.device(device)

        self.model = BalatroMLP(obs_dim, action_dim, hidden_dim).to(self.device)

    @property
    def parameters(self):
        return self.model.parameters()

    def num_parameters(self) -> int:
        return sum(p.numel() for p in self.model.parameters())

    # ------------------------------------------------------------------
    # Environment interaction
    # ------------------------------------------------------------------

    @torch.no_grad()
    def act(
        self,
        obs: np.ndarray,
        info: dict | None = None,
        action_mask: np.ndarray | None = None,
    ) -> tuple[int, float, float]:
        """Select an action for a single environment step.

        Parameters
        ----------
        obs : np.ndarray of shape (obs_dim,)
        info : dict, optional
        action_mask : np.ndarray of bool, shape (action_dim,)

        Returns
        -------
        action : int
        log_prob : float
        value : float
        """
        self.model.eval()
        obs_t = torch.tensor(obs, dtype=torch.float32, device=self.device).unsqueeze(0)

        logits, value = self.model(obs_t)
        logits = logits.squeeze(0)  # (action_dim,)
        value = value.squeeze(0)    # scalar

        # Mask invalid actions
        if action_mask is not None:
            mask_t = torch.tensor(action_mask, dtype=torch.bool, device=self.device)
            logits = logits.masked_fill(~mask_t, float("-inf"))

        dist = torch.distributions.Categorical(logits=logits)
        action = dist.sample()
        log_prob = dist.log_prob(action)

        return action.item(), log_prob.item(), value.item()

    @torch.no_grad()
    def act_batch(
        self,
        obs_batch: np.ndarray,
        mask_batch: np.ndarray | None = None,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Batch action selection for vectorized environments.

        Parameters
        ----------
        obs_batch : (num_envs, obs_dim)
        mask_batch : (num_envs, action_dim) bool, optional

        Returns
        -------
        actions : (num_envs,) int
        log_probs : (num_envs,) float
        values : (num_envs,) float
        """
        self.model.eval()
        obs_t = torch.tensor(obs_batch, dtype=torch.float32, device=self.device)

        logits, values = self.model(obs_t)

        if mask_batch is not None:
            mask_t = torch.tensor(mask_batch, dtype=torch.bool, device=self.device)
            logits = logits.masked_fill(~mask_t, float("-inf"))

        dist = torch.distributions.Categorical(logits=logits)
        actions = dist.sample()
        log_probs = dist.log_prob(actions)

        return (
            actions.cpu().numpy(),
            log_probs.cpu().numpy(),
            values.cpu().numpy(),
        )

    # ------------------------------------------------------------------
    # Training
    # ------------------------------------------------------------------

    def evaluate(
        self,
        obs_batch: torch.Tensor,
        action_batch: torch.Tensor,
        mask_batch: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Evaluate a batch of (obs, action) pairs for PPO update.

        Parameters
        ----------
        obs_batch : (B, obs_dim)
        action_batch : (B,) long
        mask_batch : (B, action_dim) bool, optional

        Returns
        -------
        log_probs : (B,)
        values : (B,)
        entropy : (B,)
        """
        self.model.train()
        logits, values = self.model(obs_batch)

        if mask_batch is not None:
            logits = logits.masked_fill(~mask_batch, float("-inf"))

        dist = torch.distributions.Categorical(logits=logits)
        log_probs = dist.log_prob(action_batch)
        entropy = dist.entropy()

        return log_probs, values, entropy

    # ------------------------------------------------------------------
    # Checkpoint
    # ------------------------------------------------------------------

    def save(self, path: str | Path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(self.model.state_dict(), path)

    def load(self, path: str | Path):
        state_dict = torch.load(path, map_location=self.device, weights_only=True)
        self.model.load_state_dict(state_dict)

    def reset(self):
        """Called at the start of each episode (no-op for PPO)."""
        pass
