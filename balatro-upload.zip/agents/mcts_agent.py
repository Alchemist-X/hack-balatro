"""Monte Carlo Tree Search (MCTS) enhanced agent for Balatro.

Uses a trained policy-value network as prior/rollout policy and
augments decisions at critical points (boss blinds, expensive shop
purchases) with look-ahead search.

Architecture follows the AlphaZero pattern:
  - Policy network provides prior action probabilities
  - Value network evaluates leaf nodes
  - UCB1 variant selects which child to expand
  - Search results are used as improved policy targets
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import torch

from agents.ppo_agent import PPOAgent


# ── MCTS Node ────────────────────────────────────────────────────────

@dataclass
class MCTSNode:
    """A node in the MCTS tree."""
    state: Any = None                  # Environment state snapshot
    parent: MCTSNode | None = None
    action: int | None = None          # Action that led to this node
    children: dict[int, MCTSNode] = field(default_factory=dict)

    visit_count: int = 0
    total_value: float = 0.0
    prior: float = 0.0                 # Prior probability from policy net

    @property
    def mean_value(self) -> float:
        if self.visit_count == 0:
            return 0.0
        return self.total_value / self.visit_count

    def is_leaf(self) -> bool:
        return len(self.children) == 0

    def ucb_score(self, c_puct: float = 1.5) -> float:
        """Upper Confidence Bound for Trees (PUCT variant)."""
        if self.parent is None:
            return 0.0
        exploration = c_puct * self.prior * math.sqrt(self.parent.visit_count) / (1 + self.visit_count)
        return self.mean_value + exploration


# ── MCTS Search ──────────────────────────────────────────────────────

class MCTS:
    """Monte Carlo Tree Search with neural network guidance.

    Parameters
    ----------
    policy_agent : PPOAgent
        Trained agent providing prior probabilities and value estimates.
    num_simulations : int
        Number of MCTS simulations per search call.
    c_puct : float
        Exploration constant for UCB.
    temperature : float
        Temperature for final action selection (0 = greedy, 1 = proportional).
    """

    def __init__(
        self,
        policy_agent: PPOAgent,
        num_simulations: int = 50,
        c_puct: float = 1.5,
        temperature: float = 1.0,
    ):
        self.policy_agent = policy_agent
        self.num_simulations = num_simulations
        self.c_puct = c_puct
        self.temperature = temperature

    def search(
        self,
        obs: np.ndarray,
        info: dict,
        action_mask: np.ndarray,
        env_snapshot: Any = None,
    ) -> tuple[int, np.ndarray]:
        """Run MCTS from the current state and return the best action.

        Parameters
        ----------
        obs : np.ndarray
            Encoded observation.
        info : dict
            Environment info dict.
        action_mask : np.ndarray
            Boolean mask of valid actions.
        env_snapshot : Any, optional
            Snapshot of environment state for simulation.
            If None, search degrades to policy-only with value backup.

        Returns
        -------
        best_action : int
        improved_policy : np.ndarray of shape (num_actions,)
            Visit-count-based improved policy distribution.
        """
        root = MCTSNode(state=env_snapshot)

        # Get prior probabilities from policy network
        action_idx, log_prob, value = self.policy_agent.act(obs, info, action_mask)
        priors = self._get_priors(obs, info, action_mask)

        # Expand root with all valid actions
        valid_actions = np.where(action_mask)[0]
        for a in valid_actions:
            child = MCTSNode(parent=root, action=a, prior=priors[a])
            root.children[a] = child

        # Run simulations
        for _ in range(self.num_simulations):
            node = root

            # Selection: traverse tree using UCB
            while not node.is_leaf():
                node = max(
                    node.children.values(),
                    key=lambda n: n.ucb_score(self.c_puct),
                )

            # Evaluation: use value network
            # In a full implementation, we would step the environment
            # and expand the node.  For now, use the value estimate.
            leaf_value = self._evaluate_leaf(node, obs, info)

            # Backpropagation
            while node is not None:
                node.visit_count += 1
                node.total_value += leaf_value
                node = node.parent

        # Extract improved policy from visit counts
        num_actions = len(action_mask)
        visit_counts = np.zeros(num_actions, dtype=np.float32)
        for a, child in root.children.items():
            visit_counts[a] = child.visit_count

        if self.temperature == 0:
            # Greedy
            best_action = int(np.argmax(visit_counts))
            improved_policy = np.zeros(num_actions, dtype=np.float32)
            improved_policy[best_action] = 1.0
        else:
            # Temperature-scaled
            counts_temp = visit_counts ** (1.0 / self.temperature)
            total = counts_temp.sum()
            if total > 0:
                improved_policy = counts_temp / total
            else:
                improved_policy = action_mask.astype(np.float32)
                improved_policy /= improved_policy.sum()
            best_action = int(np.random.choice(num_actions, p=improved_policy))

        return best_action, improved_policy

    def _get_priors(
        self, obs: np.ndarray, info: dict, action_mask: np.ndarray
    ) -> np.ndarray:
        """Get prior action probabilities from the policy network."""
        with torch.no_grad():
            tensors = self.policy_agent._obs_to_tensors(obs, batch=True)
            out = self.policy_agent.model(**tensors)
            logits = out["intent_logits"].squeeze(0).cpu().numpy()

        # Mask and softmax
        num_actions = len(action_mask)
        priors = np.zeros(num_actions, dtype=np.float32)
        valid = np.where(action_mask)[0]

        if len(valid) > 0:
            valid_logits = logits[:len(action_mask)]
            valid_logits = np.where(action_mask, valid_logits[:num_actions] if len(logits) >= num_actions else np.zeros(num_actions), -1e9)
            # Softmax
            exp_logits = np.exp(valid_logits - valid_logits.max())
            priors = exp_logits / exp_logits.sum()

        return priors

    def _evaluate_leaf(self, node: MCTSNode, obs: np.ndarray, info: dict) -> float:
        """Evaluate a leaf node using the value network."""
        _, _, value = self.policy_agent.act(obs, info)
        return value


# ── MCTS Agent ────────────────────────────────────────────────────────

class MCTSAgent:
    """Agent that combines PPO policy with MCTS at critical decision points.

    Parameters
    ----------
    policy_agent : PPOAgent
        Trained PPO agent to use as the base policy.
    num_simulations : int
        MCTS simulation budget.
    search_threshold : float
        Only activate search when the situation is "critical" enough.
        E.g., at boss blinds, expensive purchases, or when score margin
        is tight.
    """

    def __init__(
        self,
        policy_agent: PPOAgent,
        num_simulations: int = 50,
        c_puct: float = 1.5,
        temperature: float = 1.0,
        search_threshold: float = 0.0,
    ):
        self.name = "MCTSAgent"
        self.policy_agent = policy_agent
        self.mcts = MCTS(
            policy_agent=policy_agent,
            num_simulations=num_simulations,
            c_puct=c_puct,
            temperature=temperature,
        )
        self.search_threshold = search_threshold

    def act(
        self,
        obs: np.ndarray,
        info: dict | None = None,
        action_mask: np.ndarray | None = None,
    ) -> int:
        """Select an action, using MCTS at critical points."""
        info = info or {}

        if action_mask is None:
            action_mask = np.ones(64, dtype=bool)

        # Decide whether to use search
        if self._should_search(info):
            action, _ = self.mcts.search(obs, info, action_mask)
            return action
        else:
            action, _, _ = self.policy_agent.act(obs, info, action_mask)
            return action

    def _should_search(self, info: dict) -> bool:
        """Determine if the current situation warrants MCTS search."""
        # Always search at boss blinds
        if info.get("is_boss_blind", False):
            return True

        # Search when score margin is tight
        target = info.get("target_score", 0)
        current = info.get("current_score", 0)
        hands_left = info.get("hands_remaining", 1)
        if target > 0 and hands_left <= 2:
            margin = (target - current) / max(target, 1)
            if margin > 0.5:  # Need more than 50% of target still
                return True

        # Search in shop when considering expensive purchases
        if info.get("phase") == "shop":
            money = info.get("money", 0)
            shop_items = info.get("shop_items", [])
            for item in shop_items:
                cost = item.get("cost", 0)
                if cost > money * 0.5:  # Expensive relative to budget
                    return True

        return False

    def reset(self):
        pass
