"""Random agent for environment validation.

Selects uniformly at random from valid actions.  Useful for verifying
that the environment wrapper works correctly and establishing the
absolute-minimum baseline.
"""

from __future__ import annotations

import numpy as np


class RandomAgent:
    """Agent that selects a random valid action each step."""

    def __init__(self, seed: int | None = None):
        self.rng = np.random.default_rng(seed)
        self.name = "RandomAgent"

    def act(self, obs: np.ndarray, info: dict | None = None, action_mask: np.ndarray | None = None) -> int:
        """Select a random valid action.

        Parameters
        ----------
        obs : np.ndarray
            Encoded observation (unused by this agent).
        info : dict, optional
            Info dict from the environment.
        action_mask : np.ndarray of bool, optional
            Boolean mask where True = valid action.

        Returns
        -------
        int : action index
        """
        if action_mask is not None:
            valid_indices = np.where(action_mask)[0]
            if len(valid_indices) > 0:
                return int(self.rng.choice(valid_indices))

        # Fallback: pick from [0, num_actions)
        num_actions = len(action_mask) if action_mask is not None else 64
        return int(self.rng.integers(0, num_actions))

    def reset(self):
        """Called at the start of each episode."""
        pass
