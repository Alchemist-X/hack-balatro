#!/usr/bin/env python3
"""Record a full game played by an agent and export as JSON for the replay viewer.

Usage:
    python scripts/record_game.py --agent random --output replay.json
    python scripts/record_game.py --agent ppo --checkpoint checkpoints/final.pt --output replay.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from env.action_decoder import (
    action_type, ACTION_SPACE_SIZE,
    SELECT_CARD_START, SELECT_CARD_END,
    PLAY_IDX, DISCARD_IDX, CASHOUT_IDX,
    BUY_JOKER_START, BUY_JOKER_END,
    NEXT_ROUND_IDX, SELECT_BLIND_IDX,
)


def parse_args():
    p = argparse.ArgumentParser(description="Record Balatro game for replay")
    p.add_argument("--agent", type=str, default="random", choices=["random", "ppo"])
    p.add_argument("--checkpoint", type=str, default=None)
    p.add_argument("--output", type=str, default="replay.json")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", type=str, default="cpu")
    return p.parse_args()


class RandomAgent:
    name = "RandomAgent"
    def act(self, obs, info=None, action_mask=None):
        if action_mask is not None:
            valid = np.where(action_mask)[0]
            if len(valid) > 0:
                return int(np.random.choice(valid)), 0.0, 0.0
        return 0, 0.0, 0.0
    def reset(self):
        pass


def record_game(agent, seed: int) -> list[dict]:
    """Play one full game using pylatro directly and record every frame."""
    from pylatro import GameEngine

    engine = GameEngine()
    agent.reset()
    frames = []
    step = 0
    cumulative_reward = 0.0
    prev_score = 0

    # Initial frame
    frames.append(_make_frame(engine, step, "(game_start)", 0.0, 0.0))

    while not engine.is_over and step < 500:
        space = engine.gen_action_space()
        mask = np.array(space, dtype=bool)

        valid_indices = np.where(mask)[0]
        if len(valid_indices) == 0:
            break

        # Build a minimal obs for the agent (98-dim)
        obs = _build_obs(engine, mask)

        # Agent picks an action
        result = agent.act(obs, {}, mask)
        action_idx = result[0] if isinstance(result, tuple) else result

        # Validate
        if not mask[action_idx]:
            action_idx = int(valid_indices[0])

        a_name = action_type(action_idx)

        # Execute
        engine.handle_action_index(action_idx)
        step += 1

        # Compute reward
        state = engine.state
        score_delta = state.score - prev_score
        reward = 0.0
        if score_delta > 0 and state.required_score > 0:
            reward += 0.1 * np.log1p(score_delta / state.required_score)
        if engine.is_over and engine.is_win:
            reward += 10.0
        prev_score = state.score
        cumulative_reward += reward

        frames.append(_make_frame(engine, step, a_name, reward, cumulative_reward))

    return frames


def _build_obs(engine, mask: np.ndarray) -> np.ndarray:
    """Build 98-dim observation matching StateEncoder layout."""
    from env.state_encoder import OBS_DIM, ACTION_MASK_SIZE, NUM_STAGES, SCALAR_KEYS, SCALAR_NORMS, _stage_to_index
    obs = np.zeros(OBS_DIM, dtype=np.float32)

    obs[:ACTION_MASK_SIZE] = mask.astype(np.float32)

    state = engine.state
    stage_name = type(state.stage).__name__
    stage_idx = _stage_to_index(stage_name)
    obs[ACTION_MASK_SIZE + stage_idx] = 1.0

    required = max(state.required_score, 1)
    scalars = {
        "score": float(state.score),
        "required_score": float(state.required_score),
        "score_ratio": float(state.score) / float(required),
        "plays": float(state.plays),
        "discards": float(state.discards),
        "money": float(state.money),
        "round": float(state.round),
        "num_available": float(len(state.available)),
        "num_selected": float(len(state.selected)),
        "num_jokers": float(len(state.jokers)),
        "num_deck": float(len(state.deck)),
        "num_valid_actions": float(mask.sum()),
    }
    offset = ACTION_MASK_SIZE + NUM_STAGES
    for key in SCALAR_KEYS:
        obs[offset] = scalars[key] / SCALAR_NORMS[key]
        offset += 1
    return obs


def _make_frame(engine, step: int, action_name: str, reward: float, cumulative: float) -> dict:
    state = engine.state
    stage_name = type(state.stage).__name__.replace("Stage_", "")
    space = engine.gen_action_space()
    mask = np.array(space, dtype=bool)
    valid = [action_type(i) for i in range(len(mask)) if mask[i]]

    # Categorize valid actions
    can_play = bool(mask[PLAY_IDX]) if PLAY_IDX < len(mask) else False
    can_discard = bool(mask[DISCARD_IDX]) if DISCARD_IDX < len(mask) else False
    can_cashout = bool(mask[CASHOUT_IDX]) if CASHOUT_IDX < len(mask) else False
    num_selectable = int(mask[SELECT_CARD_START:SELECT_CARD_END].sum())
    num_buyable = int(mask[BUY_JOKER_START:BUY_JOKER_END].sum())
    can_next_round = bool(mask[NEXT_ROUND_IDX]) if NEXT_ROUND_IDX < len(mask) else False
    can_select_blind = bool(mask[SELECT_BLIND_IDX]) if SELECT_BLIND_IDX < len(mask) else False

    # Categorize the action taken
    a_cat = "other"
    if "select_card" in action_name:
        a_cat = "select"
    elif action_name == "play":
        a_cat = "play"
    elif action_name == "discard":
        a_cat = "discard"
    elif "move" in action_name:
        a_cat = "move"
    elif action_name == "select_blind":
        a_cat = "blind"
    elif action_name == "next_round":
        a_cat = "next"
    elif action_name == "cashout":
        a_cat = "cashout"
    elif "buy_joker" in action_name:
        a_cat = "buy"

    return {
        "step": step,
        "action": action_name,
        "action_category": a_cat,
        "reward": round(reward, 5),
        "cumulative_reward": round(cumulative, 5),
        "stage": stage_name,
        "score": state.score,
        "required_score": state.required_score,
        "score_pct": round(state.score / max(state.required_score, 1) * 100, 1),
        "plays": state.plays,
        "discards": state.discards,
        "money": state.money,
        "round": state.round,
        "num_available": len(state.available),
        "num_selected": len(state.selected),
        "num_jokers": len(state.jokers),
        "num_deck": len(state.deck),
        "num_discarded": len(state.discarded),
        "game_won": engine.is_win if engine.is_over else False,
        "is_over": engine.is_over,
        "can_play": can_play,
        "can_discard": can_discard,
        "can_cashout": can_cashout,
        "can_next_round": can_next_round,
        "can_select_blind": can_select_blind,
        "num_selectable": num_selectable,
        "num_buyable": num_buyable,
        "num_valid": int(mask.sum()),
        "valid_actions_sample": valid[:8],
    }


def main():
    args = parse_args()

    if args.agent == "ppo":
        from agents.ppo_agent import PPOAgent
        import torch
        agent = PPOAgent(device=args.device)
        if args.checkpoint:
            ckpt = torch.load(args.checkpoint, map_location=args.device, weights_only=False)
            if "model_state" in ckpt:
                agent.model.load_state_dict(ckpt["model_state"])
    else:
        agent = RandomAgent()

    np.random.seed(args.seed)
    frames = record_game(agent, seed=args.seed)

    replay = {
        "agent": agent.name,
        "seed": args.seed,
        "total_steps": len(frames),
        "won": frames[-1]["game_won"] if frames else False,
        "final_score": frames[-1]["score"] if frames else 0,
        "final_required": frames[-1]["required_score"] if frames else 0,
        "frames": frames,
    }

    output_path = Path(args.output)
    with open(output_path, "w") as f:
        json.dump(replay, f)

    print(f"Recorded {len(frames)} frames → {output_path}")
    print(f"  Agent: {agent.name}, Seed: {args.seed}")
    print(f"  Result: {'WIN' if replay['won'] else 'LOSS'}")
    print(f"  Score: {replay['final_score']} / {replay['final_required']}")


if __name__ == "__main__":
    main()
