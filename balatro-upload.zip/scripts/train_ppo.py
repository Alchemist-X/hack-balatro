#!/usr/bin/env python3
"""PPO training script for the Balatro RL agent using pylatro.

Usage:
    python scripts/train_ppo.py
    python scripts/train_ppo.py --num-envs 8 --total-steps 1000000
    python scripts/train_ppo.py --resume checkpoints/latest.pt
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np
import torch
import yaml
from tqdm import tqdm

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from agents.ppo_agent import PPOAgent
from env.balatro_gym_wrapper import BalatroEnv, ACTION_SPACE_SIZE
from env.state_encoder import OBS_DIM
from training.ppo import PPOTrainer, PPOConfig
from training.rollout import RolloutBuffer


def parse_args():
    p = argparse.ArgumentParser(description="Train Balatro PPO Agent")
    p.add_argument("--config", type=str, default="configs/train.yaml")
    p.add_argument("--resume", type=str, default=None)
    p.add_argument("--device", type=str, default="auto")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--num-envs", type=int, default=None, help="Override num parallel envs")
    p.add_argument("--total-steps", type=int, default=None, help="Override total env steps")
    p.add_argument("--no-wandb", action="store_true")
    return p.parse_args()


def load_config(path: str) -> dict:
    p = Path(path)
    if p.exists():
        with open(p) as f:
            return yaml.safe_load(f)
    return {}


class ParallelBalatroEnvs:
    """Simple synchronous parallel environment runner.

    Uses multiple BalatroEnv instances in a single process.
    This avoids the overhead of multiprocessing for fast Rust-backed envs.
    """

    def __init__(self, num_envs: int, config: dict | None = None):
        self.num_envs = num_envs
        self.envs = [BalatroEnv(config=config) for _ in range(num_envs)]
        self.obs_dim = OBS_DIM
        self.action_dim = ACTION_SPACE_SIZE

    def reset(self) -> tuple[np.ndarray, np.ndarray, list[dict]]:
        """Reset all environments.

        Returns (obs_batch, mask_batch, info_list)
        """
        obs_batch = np.zeros((self.num_envs, self.obs_dim), dtype=np.float32)
        mask_batch = np.zeros((self.num_envs, self.action_dim), dtype=bool)
        infos = []
        for i, env in enumerate(self.envs):
            obs, info = env.reset(seed=i)
            obs_batch[i] = obs
            mask_batch[i] = env.get_action_mask()
            infos.append(info)
        return obs_batch, mask_batch, infos

    def step(self, actions: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, list[dict]]:
        """Step all environments.

        Returns (obs_batch, mask_batch, rewards, dones, truncs, info_list)
        """
        obs_batch = np.zeros((self.num_envs, self.obs_dim), dtype=np.float32)
        mask_batch = np.zeros((self.num_envs, self.action_dim), dtype=bool)
        rewards = np.zeros(self.num_envs, dtype=np.float32)
        dones = np.zeros(self.num_envs, dtype=np.float32)
        truncs = np.zeros(self.num_envs, dtype=np.float32)
        infos = []

        for i, (env, action) in enumerate(zip(self.envs, actions)):
            obs, reward, terminated, truncated, info = env.step(int(action))

            if terminated or truncated:
                # Auto-reset
                obs, info = env.reset(seed=int(time.time() * 1000) % 100000 + i)
                info["episode_just_ended"] = True
                info["game_won"] = info.get("game_won", False)

            obs_batch[i] = obs
            mask_batch[i] = env.get_action_mask()
            rewards[i] = reward
            dones[i] = float(terminated or truncated)
            infos.append(info)

        return obs_batch, mask_batch, rewards, dones, truncs, infos


def main():
    args = parse_args()
    config = load_config(args.config)

    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    # ── Config ──
    ppo_cfg = config.get("ppo", {})
    train_cfg = config.get("training", {})

    num_envs = args.num_envs or ppo_cfg.get("num_envs", 16)
    steps_per_env = ppo_cfg.get("steps_per_env", 128)
    total_steps_target = args.total_steps or train_cfg.get("total_env_steps", 1_000_000)
    checkpoint_interval = train_cfg.get("checkpoint_interval", 100_000)
    log_interval = train_cfg.get("log_interval", 10_000)
    checkpoint_dir = Path(train_cfg.get("checkpoint_dir", "checkpoints"))
    checkpoint_dir.mkdir(parents=True, exist_ok=True)

    steps_per_update = steps_per_env * num_envs

    # ── Setup ──
    print("=" * 60)
    print("  Balatro PPO Training (pylatro backend)")
    print("=" * 60)
    print(f"  Num envs:         {num_envs}")
    print(f"  Steps per env:    {steps_per_env}")
    print(f"  Steps per update: {steps_per_update}")
    print(f"  Total steps:      {total_steps_target:,}")
    print(f"  Obs dim:          {OBS_DIM}")
    print(f"  Action dim:       {ACTION_SPACE_SIZE}")

    # Create agent
    agent = PPOAgent(device=args.device)
    print(f"  Model params:     {agent.num_parameters():,}")
    print(f"  Device:           {agent.device}")

    # Create trainer
    ppo_config = PPOConfig(
        clip_range=ppo_cfg.get("clip_range", 0.2),
        entropy_coef=ppo_cfg.get("entropy_coef", 0.01),
        value_loss_coef=ppo_cfg.get("value_loss_coef", 0.5),
        max_grad_norm=ppo_cfg.get("max_grad_norm", 0.5),
        num_epochs=ppo_cfg.get("num_epochs", 4),
        mini_batch_size=ppo_cfg.get("mini_batch_size", 256),
        lr=config.get("optimizer", {}).get("lr", 3e-4),
        eps=config.get("optimizer", {}).get("eps", 1e-5),
        total_optimizer_steps=total_steps_target // steps_per_update * ppo_cfg.get("num_epochs", 4),
    )
    trainer = PPOTrainer(agent, ppo_config)

    # Create rollout buffer
    buffer = RolloutBuffer(
        obs_dim=OBS_DIM,
        steps_per_env=steps_per_env,
        num_envs=num_envs,
        gamma=ppo_cfg.get("gamma", 0.99),
        gae_lambda=ppo_cfg.get("gae_lambda", 0.95),
        device=agent.device,
    )

    # Create parallel environments
    env_config = config.get("reward", {})
    envs = ParallelBalatroEnvs(num_envs, config={"reward": env_config})

    # Resume
    total_env_steps = 0
    if args.resume:
        ckpt = torch.load(args.resume, map_location=agent.device, weights_only=False)
        if "model_state" in ckpt:
            agent.model.load_state_dict(ckpt["model_state"])
        if "trainer_state" in ckpt:
            trainer.load_state_dict(ckpt["trainer_state"])
        total_env_steps = ckpt.get("total_env_steps", 0)
        print(f"  Resumed from step {total_env_steps:,}")

    print("=" * 60)
    print()

    # ── Episode tracking ──
    episode_returns = []
    episode_wins = []
    episode_lengths = []

    # ── Training loop ──
    pbar = tqdm(total=total_steps_target, initial=total_env_steps, desc="Training", unit="step")

    obs_batch, mask_batch, infos = envs.reset()

    while total_env_steps < total_steps_target:
        update_start = time.time()
        buffer.reset()

        # ── Collect rollout ──
        for step in range(steps_per_env):
            # Get actions from agent
            actions, log_probs, values = agent.act_batch(obs_batch, mask_batch)

            # Step environments
            next_obs, next_mask, rewards, dones, truncs, next_infos = envs.step(actions)

            # Store transition
            buffer.add(obs_batch, actions, rewards, dones, values, log_probs)

            # Track episodes
            for i, info in enumerate(next_infos):
                if info.get("episode_just_ended", False):
                    episode_wins.append(1.0 if info.get("game_won", False) else 0.0)

            obs_batch = next_obs
            mask_batch = next_mask
            infos = next_infos

        # ── Compute returns ──
        with torch.no_grad():
            obs_t = torch.tensor(obs_batch, dtype=torch.float32, device=agent.device)
            _, last_values = agent.model(obs_t)
            last_values = last_values.cpu().numpy()
        buffer.compute_returns(last_values)

        # ── PPO update ──
        metrics = trainer.update(buffer)

        total_env_steps += steps_per_update
        pbar.update(steps_per_update)

        # ── Logging ──
        if total_env_steps % log_interval < steps_per_update:
            update_time = time.time() - update_start
            sps = steps_per_update / max(update_time, 0.001)

            recent_wr = np.mean(episode_wins[-100:]) if episode_wins else 0.0

            pbar.set_postfix(
                loss=f"{metrics['total_loss']:.4f}",
                ent=f"{metrics['entropy']:.3f}",
                lr=f"{metrics['learning_rate']:.1e}",
                wr=f"{recent_wr:.2f}",
                sps=f"{sps:.0f}",
                eps=len(episode_wins),
            )

        # ── Checkpoint ──
        if total_env_steps % checkpoint_interval < steps_per_update:
            ckpt_path = checkpoint_dir / f"step_{total_env_steps}.pt"
            torch.save({
                "model_state": agent.model.state_dict(),
                "trainer_state": trainer.state_dict(),
                "total_env_steps": total_env_steps,
                "episode_wins": episode_wins[-1000:],
            }, ckpt_path)
            # Also save as latest
            torch.save({
                "model_state": agent.model.state_dict(),
                "trainer_state": trainer.state_dict(),
                "total_env_steps": total_env_steps,
            }, checkpoint_dir / "latest.pt")
            tqdm.write(f"  Checkpoint: {ckpt_path} (win_rate={np.mean(episode_wins[-100:]) if episode_wins else 0:.3f})")

    pbar.close()

    # ── Final save ──
    final_path = checkpoint_dir / "final.pt"
    torch.save({
        "model_state": agent.model.state_dict(),
        "total_env_steps": total_env_steps,
        "episode_wins": episode_wins[-1000:],
    }, final_path)

    recent_wr = np.mean(episode_wins[-100:]) if episode_wins else 0.0
    print(f"\nTraining complete!")
    print(f"  Total steps:    {total_env_steps:,}")
    print(f"  Total episodes: {len(episode_wins)}")
    print(f"  Recent win rate: {recent_wr:.3f}")
    print(f"  Final model:    {final_path}")


if __name__ == "__main__":
    main()
