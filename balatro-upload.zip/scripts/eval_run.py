#!/usr/bin/env python3
"""Evaluate an agent on the Balatro environment.

Usage:
    python scripts/eval_run.py --agent random --episodes 100
    python scripts/eval_run.py --agent ppo --checkpoint checkpoints/final.pt --episodes 50
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from env.balatro_gym_wrapper import BalatroEnv


def parse_args():
    p = argparse.ArgumentParser(description="Evaluate Balatro Agent")
    p.add_argument("--agent", type=str, default="random", choices=["random", "ppo"])
    p.add_argument("--checkpoint", type=str, default=None)
    p.add_argument("--episodes", type=int, default=100)
    p.add_argument("--device", type=str, default="cpu")
    p.add_argument("--seed", type=int, default=0)
    return p.parse_args()


def create_agent(agent_type: str, checkpoint: str | None = None, device: str = "cpu"):
    if agent_type == "random":
        return RandomAgent()
    elif agent_type == "ppo":
        from agents.ppo_agent import PPOAgent
        agent = PPOAgent(device=device)
        if checkpoint:
            import torch
            ckpt = torch.load(checkpoint, map_location=device, weights_only=False)
            if "model_state" in ckpt:
                agent.model.load_state_dict(ckpt["model_state"])
            else:
                agent.load(checkpoint)
        return agent
    raise ValueError(f"Unknown agent: {agent_type}")


class RandomAgent:
    name = "RandomAgent"

    def act(self, obs, info=None, action_mask=None):
        if action_mask is not None:
            valid = np.where(action_mask)[0]
            if len(valid) > 0:
                return int(np.random.choice(valid)), 0.0, 0.0
        return 0, 0.0, 0.0

    def reset(self):
        pass


def run_episode(agent, env, seed: int) -> dict:
    obs, info = env.reset(seed=seed)
    agent.reset()
    total_reward = 0.0
    steps = 0
    done = False

    while not done:
        mask = env.get_action_mask()
        result = agent.act(obs, info, mask)
        action = result[0] if isinstance(result, tuple) else result

        obs, reward, term, trunc, info = env.step(action)
        total_reward += reward
        steps += 1
        done = term or trunc

    return {
        "seed": seed,
        "steps": steps,
        "reward": total_reward,
        "won": info.get("game_won", False),
        "score": info.get("score", 0),
        "required_score": info.get("required_score", 0),
        "round": info.get("round", 0),
    }


def main():
    args = parse_args()
    agent = create_agent(args.agent, args.checkpoint, args.device)

    env = BalatroEnv()
    results = []

    print(f"Evaluating {agent.name} for {args.episodes} episodes...")
    start = time.time()

    for i in range(args.episodes):
        r = run_episode(agent, env, seed=args.seed + i)
        results.append(r)

    elapsed = time.time() - start

    # Summarize
    wins = sum(r["won"] for r in results)
    win_rate = wins / len(results)
    avg_steps = np.mean([r["steps"] for r in results])
    avg_reward = np.mean([r["reward"] for r in results])
    avg_score = np.mean([r["score"] for r in results])

    # Win streaks
    streaks = []
    current = 0
    for r in results:
        if r["won"]:
            current += 1
        else:
            if current > 0:
                streaks.append(current)
            current = 0
    if current > 0:
        streaks.append(current)
    max_streak = max(streaks) if streaks else 0

    print(f"\n{'=' * 50}")
    print(f"  Agent:           {agent.name}")
    print(f"  Episodes:        {len(results)}")
    print(f"  Win Rate:        {win_rate:.3f} ({wins}/{len(results)})")
    print(f"  Avg Steps:       {avg_steps:.1f}")
    print(f"  Avg Reward:      {avg_reward:.4f}")
    print(f"  Avg Score:       {avg_score:.0f}")
    print(f"  Max Win Streak:  {max_streak}")
    print(f"  Time:            {elapsed:.1f}s ({len(results)/elapsed:.1f} eps/s)")
    print(f"{'=' * 50}")


if __name__ == "__main__":
    main()
