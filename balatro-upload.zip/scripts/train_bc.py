#!/usr/bin/env python3
"""Behavior cloning pre-training script.

Usage:
    python scripts/train_bc.py --trajectories trajectories/rule_based.pt
    python scripts/train_bc.py --trajectories trajectories/rule_based.pt --epochs 100
"""

from __future__ import annotations

import argparse
from pathlib import Path

import yaml

# Add project root to path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from agents.ppo_agent import PPOAgent
from training.behavior_clone import BehaviorCloner


def parse_args():
    parser = argparse.ArgumentParser(description="Behavior Cloning Pre-training")
    parser.add_argument("--trajectories", type=str, required=True,
                        help="Path to trajectory .pt file")
    parser.add_argument("--config", type=str, default="configs/train.yaml",
                        help="Path to training config YAML")
    parser.add_argument("--output", type=str, default="checkpoints/bc_pretrained.pt",
                        help="Path to save pre-trained model")
    parser.add_argument("--epochs", type=int, default=None,
                        help="Override number of epochs")
    parser.add_argument("--device", type=str, default="auto")
    return parser.parse_args()


def main():
    args = parse_args()

    # Load config
    config = {}
    config_path = Path(args.config)
    if config_path.exists():
        with open(config_path) as f:
            config = yaml.safe_load(f)

    bc_cfg = config.get("behavior_cloning", {})

    print("=" * 50)
    print("  Behavior Cloning Pre-training")
    print("=" * 50)

    # Create agent
    agent = PPOAgent(device=args.device)
    print(f"  Model parameters: {agent.num_parameters():,}")
    print(f"  Device: {agent.device}")
    print(f"  Trajectories: {args.trajectories}")

    # Create cloner
    cloner = BehaviorCloner(
        agent=agent,
        lr=bc_cfg.get("lr", 1e-3),
        batch_size=bc_cfg.get("batch_size", 256),
        num_epochs=args.epochs or bc_cfg.get("num_epochs", 50),
        device=args.device,
    )

    # Train
    print()
    metrics = cloner.train(args.trajectories)
    print(f"\n  Final loss: {metrics['final_loss']:.4f}")
    print(f"  Final accuracy: {metrics['final_accuracy']:.3f}")

    # Save
    output_path = Path(args.output)
    agent.save(output_path)
    print(f"  Model saved: {output_path}")


if __name__ == "__main__":
    main()
