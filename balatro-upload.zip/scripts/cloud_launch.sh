#!/usr/bin/env bash
# ============================================================
#  Cloud training launch script for hack-balatro
#
#  Usage:
#    bash scripts/cloud_launch.sh [aws|gcp|aliyun]
#
#  This script:
#   1. Installs Python dependencies
#   2. Pulls latest code
#   3. Downloads any existing checkpoint from cloud storage
#   4. Launches PPO training
#   5. Uploads checkpoints back to cloud storage on completion
#
#  Designed to be robust to Spot instance preemption:
#   - Checkpoints are saved periodically and synced to cloud storage
#   - Training resumes from the latest checkpoint automatically
# ============================================================

set -euo pipefail

CLOUD_PROVIDER="${1:-aws}"
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
CHECKPOINT_DIR="${PROJECT_DIR}/checkpoints"
CONFIG_DIR="${PROJECT_DIR}/configs"

echo "============================================"
echo "  hack-balatro Cloud Training Launcher"
echo "  Provider: ${CLOUD_PROVIDER}"
echo "  Project:  ${PROJECT_DIR}"
echo "============================================"

# ── Step 1: Install dependencies ──
echo "[1/5] Installing dependencies..."
cd "${PROJECT_DIR}"
pip install -e . 2>/dev/null || pip install -r requirements.txt 2>/dev/null || echo "  Using existing installation"

# ── Step 2: GPU check ──
echo "[2/5] Checking GPU..."
if command -v nvidia-smi &> /dev/null; then
    nvidia-smi --query-gpu=name,memory.total --format=csv
else
    echo "  WARNING: nvidia-smi not found. Training will use CPU."
fi

# ── Step 3: Download existing checkpoints from cloud storage ──
echo "[3/5] Syncing checkpoints from cloud storage..."
mkdir -p "${CHECKPOINT_DIR}"

case "${CLOUD_PROVIDER}" in
    aws)
        BUCKET="s3://hack-balatro-training/runs/"
        if aws s3 ls "${BUCKET}" 2>/dev/null; then
            aws s3 sync "${BUCKET}checkpoints/" "${CHECKPOINT_DIR}/" --quiet
            echo "  Downloaded checkpoints from S3"
        else
            echo "  No existing checkpoints in S3"
        fi
        ;;
    gcp)
        BUCKET="gs://hack-balatro-training/runs/"
        if gsutil ls "${BUCKET}" 2>/dev/null; then
            gsutil -m rsync -r "${BUCKET}checkpoints/" "${CHECKPOINT_DIR}/"
            echo "  Downloaded checkpoints from GCS"
        else
            echo "  No existing checkpoints in GCS"
        fi
        ;;
    aliyun)
        BUCKET="oss://hack-balatro-training/runs/"
        if ossutil ls "${BUCKET}" 2>/dev/null; then
            ossutil cp -r "${BUCKET}checkpoints/" "${CHECKPOINT_DIR}/" --update
            echo "  Downloaded checkpoints from OSS"
        else
            echo "  No existing checkpoints in OSS"
        fi
        ;;
    *)
        echo "  Unknown provider: ${CLOUD_PROVIDER}. Skipping sync."
        ;;
esac

# ── Step 4: Determine resume checkpoint ──
RESUME_FLAG=""
LATEST_META="${CHECKPOINT_DIR}/latest_meta.pt"
if [ -f "${LATEST_META}" ]; then
    echo "  Found latest checkpoint metadata. Will resume training."
    RESUME_FLAG="--resume ${LATEST_META}"
fi

# ── Step 5: Launch training ──
echo "[4/5] Starting PPO training..."
python scripts/train_ppo.py \
    --config "${CONFIG_DIR}/train.yaml" \
    --device auto \
    ${RESUME_FLAG}

# ── Step 6: Upload results ──
echo "[5/5] Uploading checkpoints to cloud storage..."

case "${CLOUD_PROVIDER}" in
    aws)
        aws s3 sync "${CHECKPOINT_DIR}/" "${BUCKET}checkpoints/" --quiet
        echo "  Uploaded to S3"
        ;;
    gcp)
        gsutil -m rsync -r "${CHECKPOINT_DIR}/" "${BUCKET}checkpoints/"
        echo "  Uploaded to GCS"
        ;;
    aliyun)
        ossutil cp -r "${CHECKPOINT_DIR}/" "${BUCKET}checkpoints/" --update
        echo "  Uploaded to OSS"
        ;;
esac

echo ""
echo "============================================"
echo "  Training complete!"
echo "============================================"
