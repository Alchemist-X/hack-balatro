"""Evaluate a trained agent on a fixed set of seeds.

Collects per-episode statistics and computes aggregate metrics:
- Win rate (fraction of runs completed)
- Average blinds passed
- Average episode length
- Win streak distribution
- Average score
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
from tqdm import tqdm


def evaluate_agent(
    agent: Any,
    env_factory,
    seeds: list[int] | None = None,
    episodes_per_seed: int = 1,
    seeds_file: str | Path = "eval/seeds.json",
    verbose: bool = True,
) -> dict[str, Any]:
    """Run evaluation episodes and compute metrics.

    Parameters
    ----------
    agent : Any
        Agent with ``.act(obs, info, action_mask) -> int`` and ``.reset()``.
    env_factory : callable
        ``env_factory(seed=int) -> env`` creates a wrapped Balatro env.
    seeds : list[int], optional
        List of seeds.  If None, loads from ``seeds_file``.
    episodes_per_seed : int
        How many episodes to run per seed.
    seeds_file : str or Path
        Path to JSON file containing seed list.
    verbose : bool
        Whether to print progress.

    Returns
    -------
    dict with evaluation metrics.
    """
    if seeds is None:
        seeds = _load_seeds(seeds_file)

    results = []
    win_streak = 0
    max_streak = 0
    streaks = []

    total = len(seeds) * episodes_per_seed
    iterator = tqdm(total=total, desc="Evaluating", disable=not verbose)

    for seed in seeds:
        for _ in range(episodes_per_seed):
            episode_result = _run_episode(agent, env_factory, seed)
            results.append(episode_result)

            # Track streaks
            if episode_result["won"]:
                win_streak += 1
            else:
                if win_streak > 0:
                    streaks.append(win_streak)
                max_streak = max(max_streak, win_streak)
                win_streak = 0

            iterator.update(1)
            if verbose:
                iterator.set_postfix(
                    win_rate=f"{sum(r['won'] for r in results) / len(results):.3f}",
                    streak=win_streak,
                )

    iterator.close()

    # Final streak
    if win_streak > 0:
        streaks.append(win_streak)
        max_streak = max(max_streak, win_streak)

    # Aggregate metrics
    num_episodes = len(results)
    wins = sum(r["won"] for r in results)
    win_rate = wins / max(num_episodes, 1)

    blinds_passed = [r["blinds_passed"] for r in results]
    episode_lengths = [r["episode_length"] for r in results]
    episode_rewards = [r["episode_reward"] for r in results]

    metrics = {
        "num_episodes": num_episodes,
        "num_seeds": len(seeds),
        "win_rate": win_rate,
        "wins": wins,
        "losses": num_episodes - wins,
        "avg_blinds_passed": float(np.mean(blinds_passed)),
        "std_blinds_passed": float(np.std(blinds_passed)),
        "avg_episode_length": float(np.mean(episode_lengths)),
        "avg_episode_reward": float(np.mean(episode_rewards)),
        "max_win_streak": max_streak,
        "avg_win_streak": float(np.mean(streaks)) if streaks else 0.0,
        "streak_distribution": _streak_distribution(streaks),
    }

    if verbose:
        _print_metrics(metrics, agent_name=getattr(agent, "name", "Unknown"))

    return metrics


def _run_episode(agent: Any, env_factory, seed: int) -> dict:
    """Run a single evaluation episode."""
    env = env_factory(seed=seed)
    obs, info = env.reset(seed=seed)
    agent.reset()

    episode_reward = 0.0
    episode_length = 0
    done = False

    while not done:
        action_mask = env.get_action_mask() if hasattr(env, "get_action_mask") else None

        # Agent may return (action,) or (action, log_prob, value)
        result = agent.act(obs, info, action_mask)
        if isinstance(result, tuple):
            action = result[0]
        else:
            action = result

        obs, reward, terminated, truncated, info = env.step(action)
        episode_reward += reward
        episode_length += 1
        done = terminated or truncated

    return {
        "seed": seed,
        "won": info.get("game_won", False),
        "blinds_passed": info.get("blinds_passed", 0),
        "episode_length": episode_length,
        "episode_reward": episode_reward,
    }


def _load_seeds(path: str | Path) -> list[int]:
    """Load seed list from JSON file."""
    path = Path(path)
    if not path.exists():
        # Fallback: generate sequential seeds
        return list(range(100))
    with open(path) as f:
        data = json.load(f)
    return data.get("seeds", list(range(100)))


def _streak_distribution(streaks: list[int]) -> dict[str, int]:
    """Summarize streak distribution."""
    if not streaks:
        return {}
    dist = defaultdict(int)
    for s in streaks:
        if s >= 10:
            dist["10+"] += 1
        elif s >= 5:
            dist["5-9"] += 1
        elif s >= 3:
            dist["3-4"] += 1
        else:
            dist["1-2"] += 1
    return dict(dist)


def _print_metrics(metrics: dict, agent_name: str = "Agent"):
    """Pretty-print evaluation metrics."""
    print(f"\n{'=' * 50}")
    print(f"  Evaluation Results: {agent_name}")
    print(f"{'=' * 50}")
    print(f"  Episodes:           {metrics['num_episodes']}")
    print(f"  Win Rate:           {metrics['win_rate']:.3f} ({metrics['wins']}/{metrics['num_episodes']})")
    print(f"  Avg Blinds Passed:  {metrics['avg_blinds_passed']:.2f} +/- {metrics['std_blinds_passed']:.2f}")
    print(f"  Avg Episode Length: {metrics['avg_episode_length']:.1f}")
    print(f"  Avg Episode Reward: {metrics['avg_episode_reward']:.2f}")
    print(f"  Max Win Streak:     {metrics['max_win_streak']}")
    print(f"  Avg Win Streak:     {metrics['avg_win_streak']:.2f}")
    if metrics["streak_distribution"]:
        print(f"  Streak Dist:        {metrics['streak_distribution']}")
    print(f"{'=' * 50}\n")
