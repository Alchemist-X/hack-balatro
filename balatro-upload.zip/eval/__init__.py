"""Evaluation utilities for Balatro agents."""
