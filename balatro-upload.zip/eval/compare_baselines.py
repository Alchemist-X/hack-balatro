"""Compare multiple agents on the same seed set.

Produces a side-by-side comparison table of evaluation metrics.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from eval.eval_policy import evaluate_agent


def compare_agents(
    agents: list[Any],
    env_factory,
    seeds: list[int] | None = None,
    episodes_per_seed: int = 1,
    seeds_file: str | Path = "eval/seeds.json",
) -> dict[str, dict]:
    """Evaluate multiple agents and return a comparison dict.

    Parameters
    ----------
    agents : list
        Agents to compare.  Each must have ``.act()`` and ``.name``.
    env_factory : callable
        Creates a wrapped Balatro env given a seed.
    seeds : list[int], optional
    episodes_per_seed : int
    seeds_file : str or Path

    Returns
    -------
    dict mapping agent_name -> metrics dict
    """
    all_results = {}

    for agent in agents:
        name = getattr(agent, "name", str(type(agent).__name__))
        print(f"\n>>> Evaluating: {name}")
        metrics = evaluate_agent(
            agent=agent,
            env_factory=env_factory,
            seeds=seeds,
            episodes_per_seed=episodes_per_seed,
            seeds_file=seeds_file,
            verbose=True,
        )
        all_results[name] = metrics

    # Print comparison table
    _print_comparison(all_results)
    return all_results


def _print_comparison(results: dict[str, dict]):
    """Print a formatted comparison table."""
    agents = list(results.keys())
    if not agents:
        return

    header = f"{'Metric':<25}"
    for name in agents:
        header += f" {name:>15}"
    print(f"\n{'=' * (25 + 16 * len(agents))}")
    print(header)
    print(f"{'-' * (25 + 16 * len(agents))}")

    metrics_to_show = [
        ("Win Rate", "win_rate", ".3f"),
        ("Avg Blinds Passed", "avg_blinds_passed", ".2f"),
        ("Avg Episode Reward", "avg_episode_reward", ".2f"),
        ("Max Win Streak", "max_win_streak", "d"),
        ("Avg Win Streak", "avg_win_streak", ".2f"),
    ]

    for label, key, fmt in metrics_to_show:
        row = f"{label:<25}"
        for name in agents:
            val = results[name].get(key, 0)
            row += f" {val:>15{fmt}}"
        print(row)

    print(f"{'=' * (25 + 16 * len(agents))}\n")


def save_comparison(results: dict, path: str | Path):
    """Save comparison results to JSON."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    # Convert numpy types to native Python
    clean = {}
    for agent_name, metrics in results.items():
        clean[agent_name] = {
            k: float(v) if hasattr(v, "item") else v
            for k, v in metrics.items()
        }

    with open(path, "w") as f:
        json.dump(clean, f, indent=2, default=str)
