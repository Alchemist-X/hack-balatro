"""Transformer-based encoder for hand card sequences.

Takes a variable-length sequence of per-card feature vectors and
produces a fixed-size embedding that is permutation-invariant (via
mean pooling over the sequence dimension after self-attention).
"""

from __future__ import annotations

import math

import torch
import torch.nn as nn


class CardEncoder(nn.Module):
    """Encode a sequence of card feature vectors using a small Transformer.

    Parameters
    ----------
    input_dim : int
        Per-card raw feature dimension (default 25 = 13 rank + 4 suit + 8 enh).
    embedding_dim : int
        Internal embedding dimension for the transformer.
    num_heads : int
        Number of attention heads.
    num_layers : int
        Number of transformer encoder layers.
    max_seq_len : int
        Maximum number of cards (for positional encoding).
    dropout : float
        Dropout rate.
    """

    def __init__(
        self,
        input_dim: int = 25,
        embedding_dim: int = 64,
        num_heads: int = 4,
        num_layers: int = 2,
        max_seq_len: int = 10,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.embedding_dim = embedding_dim
        self.max_seq_len = max_seq_len

        # Project raw card features to embedding dim
        self.input_proj = nn.Linear(input_dim, embedding_dim)

        # Learnable positional encoding
        self.pos_embedding = nn.Parameter(
            torch.randn(1, max_seq_len, embedding_dim) * 0.02
        )

        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=embedding_dim,
            nhead=num_heads,
            dim_feedforward=embedding_dim * 4,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
        )
        self.transformer = nn.TransformerEncoder(
            encoder_layer, num_layers=num_layers
        )

        self.layer_norm = nn.LayerNorm(embedding_dim)

    def forward(
        self,
        card_features: torch.Tensor,
        mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Encode card features.

        Parameters
        ----------
        card_features : Tensor of shape (batch, seq_len, input_dim)
            Per-card feature vectors.  Padded cards should be all zeros.
        mask : Tensor of shape (batch, seq_len), optional
            Boolean mask where True = padding (to be ignored).

        Returns
        -------
        h_cards : Tensor of shape (batch, embedding_dim)
            Pooled card-sequence representation.
        """
        B, S, _ = card_features.shape

        # Project + positional encoding
        x = self.input_proj(card_features)  # (B, S, D)
        x = x + self.pos_embedding[:, :S, :]

        # Transformer
        if mask is not None:
            x = self.transformer(x, src_key_padding_mask=mask)
        else:
            x = self.transformer(x)

        x = self.layer_norm(x)

        # Mean pooling (ignore padding)
        if mask is not None:
            # mask: True = pad -> set to 0 before averaging
            valid_mask = (~mask).unsqueeze(-1).float()  # (B, S, 1)
            x = (x * valid_mask).sum(dim=1) / valid_mask.sum(dim=1).clamp(min=1)
        else:
            x = x.mean(dim=1)

        return x  # (B, embedding_dim)
