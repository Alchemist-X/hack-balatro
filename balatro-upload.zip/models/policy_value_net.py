"""Combined policy-value network for the Balatro RL agent.

Architecture
------------
1. **Encoder backbone** – card Transformer, Joker attention encoder,
   and a global-feature MLP are fused into a shared hidden state ``h_shared``.
2. **Intent head** – classifies the high-level strategic intent
   (play best hand, trigger joker, discard, shop buy, etc.).
3. **Action head** – scores each candidate action given ``h_shared``
   and a per-candidate feature vector.
4. **Value head** – estimates state value V(s).
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from models.card_encoder import CardEncoder
from models.joker_encoder import JokerEncoder


# ── Helper layers ─────────────────────────────────────────────────────

class ResidualMLP(nn.Module):
    """MLP block with optional residual connection."""

    def __init__(self, dim: int, dropout: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim, dim),
            nn.Dropout(dropout),
        )
        self.norm = nn.LayerNorm(dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.norm(x + self.net(x))


# ── Main network ──────────────────────────────────────────────────────

class BalatroPolicyValueNet(nn.Module):
    """Full policy-value network for the Balatro agent.

    Parameters
    ----------
    card_cfg : dict
        Keyword args for :class:`CardEncoder`.
    joker_cfg : dict
        Keyword args for :class:`JokerEncoder`.
    global_input_dim : int
        Number of global scalar features.
    global_hidden_dim : int
        Hidden size for the global-feature MLP.
    backbone_hidden_dim : int
        Width of the shared backbone.
    backbone_layers : int
        Number of residual MLP blocks in the backbone.
    num_intents : int
        Number of high-level intent categories.
    action_hidden_dim : int
        Hidden size inside the action scoring head.
    max_candidates : int
        Maximum number of candidate actions per step.
    action_feature_dim : int
        Dimension of the per-candidate action feature vector.
    dropout : float
        Dropout rate.
    """

    def __init__(
        self,
        card_cfg: dict | None = None,
        joker_cfg: dict | None = None,
        global_input_dim: int = 8,
        global_hidden_dim: int = 128,
        backbone_hidden_dim: int = 512,
        backbone_layers: int = 3,
        num_intents: int = 8,
        action_hidden_dim: int = 256,
        max_candidates: int = 64,
        action_feature_dim: int = 32,
        dropout: float = 0.1,
    ):
        super().__init__()

        card_cfg = card_cfg or {}
        joker_cfg = joker_cfg or {}

        # ── Sub-encoders ──
        self.card_encoder = CardEncoder(**card_cfg)
        self.joker_encoder = JokerEncoder(**joker_cfg)

        card_dim = self.card_encoder.embedding_dim
        joker_dim = self.joker_encoder.embedding_dim

        # Global feature MLP
        self.global_mlp = nn.Sequential(
            nn.Linear(global_input_dim, global_hidden_dim),
            nn.GELU(),
            nn.Linear(global_hidden_dim, global_hidden_dim),
            nn.GELU(),
        )

        # ── Shared backbone ──
        fused_dim = card_dim + joker_dim + global_hidden_dim
        self.backbone_proj = nn.Linear(fused_dim, backbone_hidden_dim)
        self.backbone = nn.Sequential(
            *[ResidualMLP(backbone_hidden_dim, dropout) for _ in range(backbone_layers)]
        )

        # ── Intent head ──
        self.intent_head = nn.Sequential(
            nn.Linear(backbone_hidden_dim, action_hidden_dim),
            nn.GELU(),
            nn.Linear(action_hidden_dim, num_intents),
        )

        # ── Action scoring head ──
        # Scores each candidate: concat(h_shared, action_feature) -> scalar
        self.action_proj = nn.Sequential(
            nn.Linear(backbone_hidden_dim + action_feature_dim, action_hidden_dim),
            nn.GELU(),
            nn.Linear(action_hidden_dim, 1),
        )

        # ── Value head ──
        self.value_head = nn.Sequential(
            nn.Linear(backbone_hidden_dim, action_hidden_dim),
            nn.GELU(),
            nn.Linear(action_hidden_dim, 1),
        )

        self.max_candidates = max_candidates
        self.action_feature_dim = action_feature_dim

    # ------------------------------------------------------------------

    def forward(
        self,
        card_features: torch.Tensor,
        joker_ids: torch.Tensor,
        joker_attrs: torch.Tensor,
        global_features: torch.Tensor,
        card_mask: torch.Tensor | None = None,
        joker_mask: torch.Tensor | None = None,
        action_features: torch.Tensor | None = None,
        action_mask: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        """Forward pass.

        Parameters
        ----------
        card_features : (B, max_hand, card_input_dim)
        joker_ids : (B, max_jokers) LongTensor
        joker_attrs : (B, max_jokers, joker_attr_dim)
        global_features : (B, global_input_dim)
        card_mask : (B, max_hand) bool, True = padding
        joker_mask : (B, max_jokers) bool, True = padding
        action_features : (B, num_candidates, action_feature_dim), optional
            Per-candidate feature vectors for action scoring.
        action_mask : (B, num_candidates) bool, optional
            True = invalid candidate (masked out with -inf).

        Returns
        -------
        dict with keys:
            intent_logits : (B, num_intents)
            action_logits : (B, num_candidates) or None
            value         : (B,)
        """
        # Encode sub-components
        h_cards = self.card_encoder(card_features, mask=card_mask)
        h_joker = self.joker_encoder(joker_ids, joker_attrs, mask=joker_mask)
        h_global = self.global_mlp(global_features)

        # Fuse into shared backbone
        h_fused = torch.cat([h_cards, h_joker, h_global], dim=-1)
        h_shared = self.backbone_proj(h_fused)
        h_shared = self.backbone(h_shared)  # (B, backbone_hidden_dim)

        # ── Heads ──
        intent_logits = self.intent_head(h_shared)  # (B, num_intents)
        value = self.value_head(h_shared).squeeze(-1)  # (B,)

        action_logits = None
        if action_features is not None:
            B, C, _ = action_features.shape
            # Expand h_shared to match candidates
            h_exp = h_shared.unsqueeze(1).expand(B, C, -1)  # (B, C, D)
            combined = torch.cat([h_exp, action_features], dim=-1)  # (B, C, D+F)
            action_logits = self.action_proj(combined).squeeze(-1)  # (B, C)

            # Mask invalid actions
            if action_mask is not None:
                action_logits = action_logits.masked_fill(action_mask, float("-inf"))

        return {
            "intent_logits": intent_logits,
            "action_logits": action_logits,
            "value": value,
        }

    # ------------------------------------------------------------------
    # Convenience methods
    # ------------------------------------------------------------------

    def get_value(
        self,
        card_features: torch.Tensor,
        joker_ids: torch.Tensor,
        joker_attrs: torch.Tensor,
        global_features: torch.Tensor,
        **kwargs,
    ) -> torch.Tensor:
        """Return only the value estimate (useful during rollouts)."""
        out = self.forward(
            card_features, joker_ids, joker_attrs, global_features, **kwargs
        )
        return out["value"]

    def get_action_and_value(
        self,
        card_features: torch.Tensor,
        joker_ids: torch.Tensor,
        joker_attrs: torch.Tensor,
        global_features: torch.Tensor,
        action_features: torch.Tensor | None = None,
        action_mask: torch.Tensor | None = None,
        **kwargs,
    ) -> tuple[torch.distributions.Categorical, torch.Tensor, torch.Tensor]:
        """Sample an action and return (distribution, action, value).

        Returns
        -------
        dist : Categorical distribution over candidate actions (or intents)
        action : sampled action index
        value : V(s)
        """
        out = self.forward(
            card_features, joker_ids, joker_attrs, global_features,
            action_features=action_features,
            action_mask=action_mask,
            **kwargs,
        )

        # Use action logits if available, otherwise fall back to intent logits
        logits = out["action_logits"] if out["action_logits"] is not None else out["intent_logits"]
        dist = torch.distributions.Categorical(logits=logits)
        action = dist.sample()

        return dist, action, out["value"]
