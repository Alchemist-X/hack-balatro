"""Attention-based encoder for Joker sequences.

Each Joker is represented by an integer ID (looked up in an embedding table)
plus a vector of numeric attributes.  The sequence is processed with
multi-head self-attention and then pooled into a fixed-size vector.
"""

from __future__ import annotations

import torch
import torch.nn as nn


class JokerEncoder(nn.Module):
    """Encode a variable-length Joker sequence using attention pooling.

    Parameters
    ----------
    num_joker_types : int
        Total number of distinct Joker IDs.
    joker_attr_dim : int
        Dimension of numeric Joker attributes (rarity, chips, mult, ...).
    embedding_dim : int
        Output embedding dimension.
    num_heads : int
        Number of self-attention heads.
    num_layers : int
        Number of attention layers.
    max_jokers : int
        Maximum number of Jokers the agent can hold.
    dropout : float
        Dropout rate.
    """

    def __init__(
        self,
        num_joker_types: int = 150,
        joker_attr_dim: int = 8,
        embedding_dim: int = 64,
        num_heads: int = 2,
        num_layers: int = 2,
        max_jokers: int = 5,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.embedding_dim = embedding_dim
        self.max_jokers = max_jokers

        # Joker ID embedding
        self.id_embedding = nn.Embedding(
            num_joker_types + 1, embedding_dim, padding_idx=0
        )

        # Project numeric attributes
        self.attr_proj = nn.Linear(joker_attr_dim, embedding_dim)

        # Combine ID embedding + attribute projection
        self.combine = nn.Linear(embedding_dim * 2, embedding_dim)

        # Positional encoding (slot-based)
        self.pos_embedding = nn.Parameter(
            torch.randn(1, max_jokers, embedding_dim) * 0.02
        )

        # Self-attention layers
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=embedding_dim,
            nhead=num_heads,
            dim_feedforward=embedding_dim * 4,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
        )
        self.attention = nn.TransformerEncoder(
            encoder_layer, num_layers=num_layers
        )

        self.layer_norm = nn.LayerNorm(embedding_dim)

    def forward(
        self,
        joker_ids: torch.Tensor,
        joker_attrs: torch.Tensor,
        mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Encode a batch of Joker sequences.

        Parameters
        ----------
        joker_ids : LongTensor of shape (batch, max_jokers)
            Joker type IDs.  0 = padding / empty slot.
        joker_attrs : FloatTensor of shape (batch, max_jokers, joker_attr_dim)
            Numeric attributes for each Joker.
        mask : BoolTensor of shape (batch, max_jokers), optional
            True = padding position (ignored by attention).

        Returns
        -------
        h_joker : Tensor of shape (batch, embedding_dim)
        """
        B, S = joker_ids.shape

        # Embed IDs and attributes
        id_emb = self.id_embedding(joker_ids)       # (B, S, D)
        attr_emb = self.attr_proj(joker_attrs)       # (B, S, D)

        # Combine
        combined = torch.cat([id_emb, attr_emb], dim=-1)  # (B, S, 2D)
        x = self.combine(combined)                          # (B, S, D)

        # Add positional encoding
        x = x + self.pos_embedding[:, :S, :]

        # Self-attention
        if mask is not None:
            x = self.attention(x, src_key_padding_mask=mask)
        else:
            x = self.attention(x)

        x = self.layer_norm(x)

        # Attention-weighted pooling
        if mask is not None:
            valid = (~mask).unsqueeze(-1).float()
            x = (x * valid).sum(dim=1) / valid.sum(dim=1).clamp(min=1)
        else:
            x = x.mean(dim=1)

        return x  # (B, embedding_dim)
