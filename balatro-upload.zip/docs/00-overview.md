# hack-balatro 项目总览

## 一句话

用强化学习训练一个能在 Balatro 里超越人类玩家的 AI Agent。

## 到目前为止发生了什么

### 阶段 1：调研与规划

- 搜索了 GitHub 上所有与 Balatro AI 相关的仓库
- 发现 **balatro-gym** 名不副实（只是个 8 张牌 draw poker），**pylatro**（balatro-rs 的 Python 绑定）才有真正的 Balatro 规则（盲注、Joker、商店、多轮 ante）
- 确定技术路线：pylatro 做模拟器 → Gymnasium 封装 → PPO 训练 → MCTS 增强 → 超人类评估

### 阶段 2：项目骨架搭建

创建了完整的项目结构，包含 6 个核心模块（env / models / agents / training / eval / scripts），3 套配置（env / model / train），3 个云厂商训练配置（AWS / GCP / 阿里云）。

### 阶段 3：环境接入

- 用 Homebrew 安装了 Python 3.12 和 Rust 1.93
- 编译安装了 pylatro（balatro-rs 的 PyO3 绑定）
- 重写了环境层，将 pylatro 的 GameEngine 封装为标准 Gymnasium 接口
- 动作空间：固定 79 维离散空间 + action mask
- 观测空间：98 维（79 action mask + 7 stage one-hot + 12 标量特征）

### 阶段 4：训练管线验证

- 实现了真实的 PPO 训练循环（非占位符）
- 本地 CPU 吞吐量达到 **19,000 steps/sec**
- 100K 步训练后，PPO agent 的平均分从 94（随机）提升到 137（目标 300），确认有学习信号
- 环境稳定运行超过 2000 局，零崩溃

## 项目结构

```
hack-balatro/
├── configs/           ← 环境、模型、训练、云端配置
│   ├── cloud/         ← AWS / GCP / 阿里云 H100 训练配置
│   ├── env.yaml
│   ├── model.yaml
│   └── train.yaml
├── env/               ← Balatro 环境封装层（pylatro → Gymnasium）
├── models/            ← 神经网络模块（目前未在主管线中使用）
├── agents/            ← Agent 实现（Random / RuleBased / PPO / MCTS）
├── training/          ← 训练管线（Rollout / PPO / BC / Curriculum）
├── eval/              ← 评估框架（固定种子 / 多 Agent 对比）
├── scripts/           ← 入口脚本（训练 / 评估 / 云端启动）
├── docs/              ← 你正在读的文档
└── vendor/            ← 第三方依赖（balatro-rs 源码）
```

## 数据流

```
pylatro GameEngine
    ↓ (gen_action_space → 79-dim mask)
    ↓ (state → score, plays, discards, money...)
BalatroEnv (Gymnasium 封装)
    ↓ obs: 98-dim float32
    ↓ action_mask: 79-dim bool
PPOAgent (BalatroMLP)
    ↓ 选择动作 (masked softmax)
    ↓ 返回 action, log_prob, value
BalatroEnv.step(action)
    ↓ → handle_action_index(action)
    ↓ → shaped reward
RolloutBuffer (收集 N 步 × M 个并行环境)
    ↓ GAE 计算
PPOTrainer (clip + entropy + value loss)
    ↓ 更新模型参数
    ↓ 循环...
```

## 下一步

1. **更长训练**：100 万 → 1 亿步，观察 win rate 变化
2. **更丰富观测**：当前 98 维太简陋，需要加入卡牌具体信息
3. **上云训练**：用 H100 加速（`scripts/cloud_launch.sh aws`）
4. **搜索增强**：在 Boss 盲注启用 MCTS
5. **超人类评估**：固定种子集 + 人类对比
