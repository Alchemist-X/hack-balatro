# eval/ — 评估框架

## 职责

在固定种子集上评估 agent 表现，生成可复现、可对比的指标。

## 文件清单

| 文件 | 行数 | 作用 |
|------|------|------|
| `seeds.json` | — | 100 个固定测试种子 |
| `eval_policy.py` | 196 | 单 agent 评估（通关率、连胜分布等） |
| `compare_baselines.py` | 104 | 多 agent 横向对比 |

## 评估指标

| 指标 | 含义 |
|------|------|
| Win Rate | 通关率（完成所有 ante） |
| Avg Blinds Passed | 平均通过的盲注数 |
| Avg Episode Length | 平均每局步数 |
| Avg Episode Reward | 平均每局累计 reward |
| Max Win Streak | 最长连胜次数 |
| Avg Win Streak | 平均连胜长度 |
| Streak Distribution | 连胜分布（1-2 / 3-4 / 5-9 / 10+） |

## 使用方法

### 评估单个 agent

```bash
# 随机 agent
python scripts/eval_run.py --agent random --episodes 200

# 训练后的 PPO agent
python scripts/eval_run.py --agent ppo --checkpoint checkpoints/final.pt --episodes 200
```

### 当前基线数据

| Agent | 训练量 | 平均分 | Win Rate |
|-------|--------|--------|----------|
| RandomAgent | — | 94 | 0.0% |
| PPOAgent | 100K steps | 137 | 0.0% |

目标：通过更长训练让 PPO 过第一关（300 分），然后逐步推进到通关。

## 连胜的意义

Balatro 的核心挑战不只是"能不能通关"，而是"能不能稳定通关"。连胜次数直接衡量策略的鲁棒性：
- 人类顶级玩家在标准难度下可以连胜 5-10 次
- 超人类目标：连胜分布显著优于人类
