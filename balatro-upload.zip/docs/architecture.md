# Network Architecture

## Overview

The Balatro RL agent uses a multi-encoder architecture that processes
heterogeneous game state components through specialized sub-networks,
fuses them into a shared backbone, and produces policy and value outputs.

## Data Flow

```
Raw Observation
    |
    +---> Hand Cards (max 10 x 25)  ---> CardEncoder (Transformer)  ---> h_cards (64)
    |
    +---> Joker IDs (max 5)         ---> JokerEncoder (Attention)   ---> h_joker (64)
    |     Joker Attrs (max 5 x 8)
    |
    +---> Global Features (8)       ---> Global MLP                 ---> h_global (128)
    |
    +---> Concatenate: [h_cards | h_joker | h_global] = 256
    |
    +---> Backbone Projection (256 -> 512)
    |
    +---> Residual MLP x3 (512)  -----> h_shared (512)
              |           |           |
              v           v           v
        Intent Head   Action Head  Value Head
        (8 intents)   (per-cand.)  (scalar)
```

## Component Details

### CardEncoder

- Input: (batch, max_hand=10, 25)
  - 13-dim rank one-hot
  - 4-dim suit one-hot
  - 8-dim enhancement flags
- Architecture: Linear projection (25 -> 64) + learnable positional encoding + 2-layer Transformer (4 heads)
- Output: mean-pooled (batch, 64)

### JokerEncoder

- Input: joker IDs (batch, max_jokers=5) + attrs (batch, 5, 8)
- Architecture: ID embedding (150 -> 64) + attribute projection (8 -> 64) + concatenate + project (128 -> 64) + positional encoding + 2-layer Transformer (2 heads)
- Output: mean-pooled (batch, 64)

### Global MLP

- Input: 8 normalized scalar features
- Architecture: 2-layer MLP (8 -> 128 -> 128)
- Features: blind_type, blind_level, target_score, current_score, hands_remaining, discards_remaining, money, deck_size

### Shared Backbone

- Input: concatenated (batch, 256)
- Architecture: projection (256 -> 512) + 3 x ResidualMLP (512)
- Each ResidualMLP: Linear(512->512) + GELU + Dropout + Linear(512->512) + Dropout + LayerNorm + residual

### Intent Head

- Input: h_shared (batch, 512)
- Output: logits over 8 intent categories
- Intents: play_best_hand, play_for_joker, play_conservative, discard_bad, discard_for_draw, shop_buy, shop_reroll, shop_skip

### Action Head

- Input: h_shared (batch, 512) + per-candidate features (batch, C, 32)
- Architecture: concat -> Linear(544 -> 256) -> GELU -> Linear(256 -> 1)
- Output: per-candidate scores (batch, C)

### Value Head

- Input: h_shared (batch, 512)
- Architecture: Linear(512 -> 256) -> GELU -> Linear(256 -> 1)
- Output: scalar V(s)

## Parameter Count

| Component | Parameters |
|-----------|-----------|
| CardEncoder | ~270K |
| JokerEncoder | ~230K |
| Global MLP | ~17K |
| Backbone | ~4.0M |
| Intent Head | ~133K |
| Action Head | ~140K |
| Value Head | ~132K |
| **Total** | **~15M** |
