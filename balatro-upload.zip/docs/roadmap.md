# Roadmap

## Completed

- [x] Project skeleton and directory structure
- [x] Configuration files (env, model, training, cloud)
- [x] State encoder (hand cards, jokers, global features)
- [x] Action decoder (simplified mode with candidate enumeration)
- [x] Neural network architecture (CardEncoder, JokerEncoder, PolicyValueNet)
- [x] PPO Agent with observation parsing and checkpoint support
- [x] MCTS Agent with UCB search and policy network guidance
- [x] Random and Rule-based baseline agents
- [x] Rollout buffer with GAE computation
- [x] PPO trainer with clipped surrogate loss
- [x] Behavior cloning pre-trainer
- [x] Curriculum learning scheduler
- [x] Evaluation framework (per-seed, streak distribution)
- [x] Multi-agent comparison tool
- [x] Training and evaluation entry scripts
- [x] Cloud launch script (AWS/GCP/Aliyun)

## Phase 1: Environment Integration

- [ ] Install and test balatro-gym (`pip install balatro-gym`)
- [ ] Adapt state_encoder to match actual observation format
- [ ] Adapt action_decoder to match actual action format
- [ ] Run RandomAgent for 100+ episodes to validate environment stability
- [ ] Profile environment step throughput (target: >1000 steps/sec)

## Phase 2: Baseline Validation

- [ ] Tune RuleBasedAgent heuristics on actual game mechanics
- [ ] Collect 10K+ trajectories from RuleBasedAgent
- [ ] Save trajectories as .pt files for behavior cloning
- [ ] Establish baseline metrics on fixed seed set

## Phase 3: Neural Network Training

- [ ] Run behavior cloning pre-training on rule-based trajectories
- [ ] Verify model can achieve >50% accuracy on BC task
- [ ] Begin PPO training at easy difficulty
- [ ] Monitor training curves with wandb

## Phase 4: Scaling Up

- [ ] Deploy to cloud H100 instance for faster training
- [ ] Run 1e8+ environment steps with PPO
- [ ] Implement curriculum level advancement
- [ ] Compare PPO agent vs rule-based baseline

## Phase 5: Search Enhancement

- [ ] Enable MCTS at boss blinds and key shop decisions
- [ ] Tune MCTS simulation budget vs computation cost
- [ ] Train improved policy using MCTS-enhanced targets (AlphaZero-style)

## Phase 6: Superhuman Evaluation

- [ ] Collect human player data (or use community benchmarks)
- [ ] Run comprehensive evaluation on 100+ seeds
- [ ] Compare win rate and streak distribution vs human data
- [ ] Document findings

## Future Directions

- [ ] Integrate balatro-rs as high-performance simulation backend
- [ ] Connect trained agent to real game via coder/balatrobot
- [ ] Explore interpretable strategy analysis (attention visualization)
- [ ] Risk-constrained optimization for consistent win streaks
- [ ] Multi-agent self-play for further improvement
