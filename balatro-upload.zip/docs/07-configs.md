# configs/ — 配置文件

## 职责

集中管理所有超参数和环境设定，避免硬编码散落在代码各处。

## 文件清单

| 文件 | 管什么 |
|------|--------|
| `env.yaml` | 环境参数：并行数、难度、观测编码、动作空间 |
| `model.yaml` | 网络结构：encoder 维度、层数、头数、骨干宽度 |
| `train.yaml` | 训练超参：PPO 参数、优化器、reward shaping、BC、课程学习 |
| `cloud/aws_p5.yaml` | AWS P5 实例（8×H100）配置 |
| `cloud/gcp_a3.yaml` | GCP A3 实例配置 |
| `cloud/aliyun_gpu.yaml` | 阿里云 H100 实例配置 |

## 关键超参数速查

### PPO

| 参数 | 值 | 含义 |
|------|------|------|
| gamma | 0.99 | 折扣因子 |
| gae_lambda | 0.95 | GAE lambda |
| clip_range | 0.2 | PPO 截断范围 |
| entropy_coef | 0.01 | 熵正则系数（鼓励探索） |
| value_loss_coef | 0.5 | 价值损失权重 |
| max_grad_norm | 0.5 | 梯度裁剪 |
| num_epochs | 4 | 每轮 rollout 更新几遍 |
| steps_per_env | 256 | 每个环境每轮收集多少步 |
| num_envs | 64 | 并行环境数 |
| mini_batch_size | 512 | 小批量大小 |
| lr | 2e-4 | 学习率 |

### Reward Shaping

| 参数 | 值 | 含义 |
|------|------|------|
| win_reward | 10.0 | 通关奖励 |
| blind_pass_reward | 0.5 | 过盲注奖励 |
| boss_pass_reward | 1.0 | 过 Boss 额外奖励 |
| score_shaping_scale | 0.1 | 得分进度奖励缩放 |
| streak_bonus | 0.2 | 连胜额外奖励 |

### 课程学习

| 级别 | max_ante | 晋升 win_rate | 最少局数 |
|------|---------|-------------|---------|
| easy | 4 | 60% | 5,000 |
| standard | 8 | 40% | 10,000 |
| hard | 8 | — | — |

### 云端成本估算

| 阶段 | 环境步数 | 卡数 | 时间 | 成本 |
|------|---------|------|------|------|
| 调试 | 1e7 | 1×H100 | 10-20h | $60-200 |
| PPO 训练 | 1e8 | 1×H100 | 20-40h | $120-400 |
| 搜索+课程 | 5e8 | 4-8×H100 | 1-3天 | $600-3000 |
