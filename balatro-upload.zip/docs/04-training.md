# training/ — 训练管线

## 职责

实现强化学习的训练流程：数据收集 → 优势计算 → 策略更新。

## 文件清单

| 文件 | 行数 | 作用 |
|------|------|------|
| `rollout.py` | 138 | Rollout buffer：存储轨迹 + GAE 计算 |
| `ppo.py` | 161 | PPO 算法：clipped surrogate + entropy + value loss |
| `behavior_clone.py` | 141 | 行为克隆：用专家轨迹做监督预训练 |
| `curriculum.py` | 183 | 课程学习：按 win rate 逐步提升难度 |

## 核心流程

### 1. Rollout 收集

`RolloutBuffer` 预分配 `(steps_per_env × num_envs)` 的存储空间。

每一步存：
- `observations` (98 维)
- `actions` (int)
- `rewards` (float)
- `dones` (0/1)
- `values` (模型估计的 V(s))
- `log_probs` (模型给出的 π(a|s) 的 log)

### 2. GAE 计算

收集完一轮后调用 `compute_returns(last_values)`：

```
δ_t = r_t + γ · V(s_{t+1}) · (1 - done_t) - V(s_t)
A_t = δ_t + γλ · (1 - done_t) · A_{t+1}       ← GAE
Return_t = A_t + V(s_t)
```

默认超参：γ = 0.99, λ = 0.95

### 3. PPO 更新

`PPOTrainer.update()` 对 buffer 中的数据做多轮（num_epochs）小批量更新。

每个 mini-batch 的损失：

```
ratio = exp(log_π_new(a|s) - log_π_old(a|s))
L_clip = -min(ratio · A, clip(ratio, 1-ε, 1+ε) · A)
L_value = 0.5 · (V(s) - Return)²
L_entropy = -H(π)
L_total = L_clip + 0.5 · L_value - 0.01 · L_entropy
```

关键：评估时传入 action mask，确保 log_prob 计算正确。

### 4. 行为克隆（可选预训练）

`BehaviorCloner` 用专家/规则 agent 的轨迹做监督学习：
- 输入：`trajectories/rule_based.pt`（包含 observations 和 actions）
- 用交叉熵损失训练策略头
- 让 PPO 不从完全随机开始

### 5. 课程学习

`CurriculumScheduler` 管理三个难度级别：

| 级别 | max_ante | 晋升条件 |
|------|---------|---------|
| easy | 4 | win_rate > 60%，至少 5000 局 |
| standard | 8 | win_rate > 40%，至少 10000 局 |
| hard | 8 | 最终级别 |

每局报告结果 → 检查是否达标 → 自动晋升。

## 性能数据

在 Apple Silicon (M-series) CPU 上：

| 配置 | 吞吐量 |
|------|--------|
| 4 envs, 256 steps | ~13,000 steps/sec |
| 8 envs, 256 steps | ~19,000 steps/sec |

100K 步训练耗时约 5 秒。1 亿步预计约 1.5 小时。
