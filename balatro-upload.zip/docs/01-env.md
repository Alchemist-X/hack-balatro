# env/ — 环境封装层

## 职责

把 pylatro（Rust 写的 Balatro 模拟器）封装成标准的 Gymnasium 接口，让 RL 算法可以直接 `env.reset()` / `env.step(action)` 训练。

## 文件清单

| 文件 | 行数 | 作用 |
|------|------|------|
| `__init__.py` | 8 | 导出 `BalatroEnv`, `make_env`, `make_vec_env` 等 |
| `balatro_gym_wrapper.py` | 236 | 核心：Gymnasium 环境类 |
| `state_encoder.py` | 150 | 把 GameState 编码为 98 维 float32 向量 |
| `action_decoder.py` | 112 | 动作索引的类型判断和验证工具 |
| `balatro_rs_env.py` | 40 | 预留的高性能后端占位（未实现） |

## 核心类：BalatroEnv

```python
env = BalatroEnv(config={"reward": {...}})
obs, info = env.reset(seed=42)
mask = env.get_action_mask()          # shape (79,), bool
obs, reward, terminated, truncated, info = env.step(action_idx)
```

### 动作空间

固定长度 79，由 balatro-rs 定义：

| 索引范围 | 数量 | 含义 |
|---------|------|------|
| 0-23 | 24 | 选择/取消选择一张手牌 |
| 24-46 | 23 | 把一张牌左移（调整顺序） |
| 47-69 | 23 | 把一张牌右移 |
| 70 | 1 | 打出已选的牌 |
| 71 | 1 | 弃掉已选的牌 |
| 72 | 1 | 兑现（Cash Out） |
| 73-76 | 4 | 从商店买 Joker |
| 77 | 1 | 进入下一轮 |
| 78 | 1 | 选择盲注（开始打牌） |

每一步只有部分动作合法——通过 `get_action_mask()` 返回的 `bool[79]` 告诉 agent 哪些能选。

### 观测空间

98 维 float32 向量，由 `StateEncoder` 生成：

| 区段 | 维度 | 内容 |
|------|------|------|
| 0-78 | 79 | action mask（合法动作 = 1.0） |
| 79-85 | 7 | 游戏阶段 one-hot（PreBlind / Blind / PostBlind / Shop / End / CashOut / Other） |
| 86-97 | 12 | 归一化标量：score, required_score, score_ratio, plays, discards, money, round, num_available, num_selected, num_jokers, num_deck, num_valid_actions |

### Reward Shaping

```
reward = 0
if score_delta > 0:
    reward += 0.1 * log(1 + score_delta / required_score)   # 得分进度
if blind_passed:
    reward += 0.5                                            # 通过盲注
if game_won:
    reward += 10.0                                           # 通关
```

## 为什么不用 balatro-gym？

cassiusfive/balatro-gym 虽然名字里有 "balatro"，但实际只实现了一个 8 张牌 draw poker 小游戏——没有盲注、Joker、商店、roguelike 循环。pylatro（evanofslack/balatro-rs）才有真正的 Balatro 规则。

## 当前局限

- pylatro 的 Card 对象没有暴露 rank/suit 给 Python（PyO3 缺少 getter），所以观测里看不到具体牌面信息
- 缺少塔罗牌、行星牌、Boss 盲注特殊效果
- 没有种子控制（pylatro 当前不支持传入种子）
