# agents/ — Agent 实现

## 职责

实现不同策略的 Agent，全部遵循统一接口：

```python
action, log_prob, value = agent.act(obs, info, action_mask)
agent.reset()
```

## Agent 一览

| Agent | 文件 | 用途 | 复杂度 |
|-------|------|------|--------|
| RandomAgent | `random_agent.py` | 环境验证 | 零 |
| RuleBasedAgent | `rule_based_agent.py` | 基线 + 行为克隆数据源 | 中 |
| PPOAgent | `ppo_agent.py` | **主力训练 agent** | 高 |
| MCTSAgent | `mcts_agent.py` | 搜索增强（未来阶段） | 很高 |

## RandomAgent

从合法动作中均匀随机选一个。用来验证环境没 bug。

- 200 局表现：平均分 94，win rate 0%

## RuleBasedAgent

手写规则策略：
- 打牌阶段：找手牌中最高分的扑克牌型（同花顺 > 四条 > 葫芦 > ...），优先出
- 弃牌阶段：弃低价值牌
- 商店阶段：钱够就买第一个 Joker，否则跳过
- 盲注选择：永远接受

支持轨迹录制（`start_recording()` / `stop_recording()`），用于生成行为克隆训练数据。

注意：当前版本的规则策略对 pylatro 的适配还不完整，因为 Card 属性无法直接读取。

## PPOAgent（主力）

基于 PPO 算法的学习型 agent。

核心组件：
- **BalatroMLP**：98 维输入 → 256 宽 2 层共享 → 79 维 action logits + 1 维 value
- **action masking**：无效动作 logits 设为 -inf，确保只采样合法动作
- **batch 推理**：`act_batch()` 一次处理 N 个并行环境

关键方法：
- `act(obs, info, mask)` → (action, log_prob, value) — 单步决策
- `act_batch(obs_batch, mask_batch)` → (actions, log_probs, values) — 批量决策
- `evaluate(obs, actions, masks)` → (log_probs, values, entropy) — PPO 更新时用

设备支持：自动检测 CUDA > MPS > CPU。

100K 步训练后表现：平均分 137，比随机提升 46%。

## MCTSAgent

在关键决策点（Boss 盲注、紧张局面、大额购买）启用蒙特卡洛树搜索。

工作方式：
1. 用 PPO 策略网络提供先验概率和价值估计
2. UCB 选择 → 扩展 → 价值评估 → 回传
3. 按访问次数分布选最终动作

触发条件（`_should_search()`）：
- Boss 盲注
- 剩余出牌次数 ≤ 2 且差距 > 50%
- 商店里有超过预算 50% 的贵重物品

当前为框架代码，因为完整搜索需要环境快照（state copy），pylatro 暂不支持。
