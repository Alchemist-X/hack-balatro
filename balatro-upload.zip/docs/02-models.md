# models/ — 神经网络模块

## 职责

定义 RL agent 使用的神经网络架构。包含两套设计：

1. **当前使用**：`agents/ppo_agent.py` 里的 `BalatroMLP`（简单 MLP，适配 98 维观测）
2. **预留的高级架构**：`models/` 目录下的 Transformer-based 网络，用于未来观测更丰富时切换

## 当前使用的网络：BalatroMLP

定义在 `agents/ppo_agent.py`，不在 `models/` 目录。

```
输入: obs (98,)
  ↓
共享层: Linear(98 → 256) → ReLU → Linear(256 → 256) → ReLU
  ↓                                    ↓
策略头: Linear(256 → 256) → ReLU    价值头: Linear(256 → 128) → ReLU
  ↓     → Linear(256 → 79)             ↓   → Linear(128 → 1)
action_logits (79,)                  value (标量)
```

- 参数量：约 21 万
- 输出的 action_logits 会被 action mask 过滤（无效动作设为 -inf），再做 softmax 采样

## 预留的高级架构

`models/` 目录包含三个模块，为未来 pylatro 暴露卡牌信息后准备：

### card_encoder.py — CardEncoder

- 2 层 4 头 Transformer
- 输入：每张牌的 25 维特征（13 rank + 4 suit + 8 enhancement）
- 输出：64 维牌组表示（mean pooling）
- 支持 padding mask

### joker_encoder.py — JokerEncoder

- 2 层 2 头 Attention
- 输入：Joker ID embedding (150 种) + 8 维属性
- 输出：64 维 Joker 组合表示
- 支持变长序列

### policy_value_net.py — BalatroPolicyValueNet

完整的多编码器架构：

```
手牌 → CardEncoder → h_cards (64)
Joker → JokerEncoder → h_joker (64)
全局特征 → MLP → h_global (128)
    ↓
concat → [256] → 骨干 MLP (3 层 ResidualMLP, 512 宽) → h_shared
    ↓              ↓              ↓
意图策略头(8)   动作评分头     价值头(1)
```

总参数量约 1500 万。目前未接入训练管线，因为 pylatro 暂不暴露卡牌详细信息。

## 何时切换

当满足以下条件之一时，应从 BalatroMLP 切换到 BalatroPolicyValueNet：
- pylatro 暴露了 Card 的 rank/suit 属性
- 我们修改了 pylatro 的 PyO3 绑定来暴露这些属性
- 观测维度显著增加（比如 >500 维）
