# scripts/ — 入口脚本与云端部署

## 职责

提供可直接运行的命令行入口，覆盖训练、评估、云端部署三个场景。

## 脚本清单

| 脚本 | 用途 | 典型用法 |
|------|------|----------|
| `train_ppo.py` | PPO 训练 | `python scripts/train_ppo.py --num-envs 8 --total-steps 1000000` |
| `train_bc.py` | 行为克隆预训练 | `python scripts/train_bc.py --trajectories trajectories/rule_based.pt` |
| `eval_run.py` | 评估 agent | `python scripts/eval_run.py --agent ppo --checkpoint checkpoints/final.pt` |
| `cloud_launch.sh` | 云端一键训练 | `bash scripts/cloud_launch.sh aws` |

## train_ppo.py — PPO 训练

核心流程：

1. 创建 `ParallelBalatroEnvs`（同步并行，单进程多实例）
2. 创建 `PPOAgent` + `PPOTrainer` + `RolloutBuffer`
3. 循环：
   - 收集 `steps_per_env × num_envs` 步的 rollout
   - 计算 GAE returns
   - 做 4 轮 PPO 更新
   - 每 10K 步打印 loss / entropy / win_rate
   - 每 100K 步保存 checkpoint

关键参数：
- `--num-envs`：并行环境数（默认 16，调小可节省内存）
- `--total-steps`：总环境步数（默认 100 万）
- `--resume`：从 checkpoint 恢复训练
- `--no-wandb`：禁用 wandb 日志
- `--device`：cpu / cuda / mps / auto

### ParallelBalatroEnvs

没有用 `gymnasium.vector.AsyncVectorEnv`，而是自己写了一个同步并行器。原因：
- pylatro 是 Rust 后端，单步极快（<1ms）
- 多进程的 IPC 开销反而比环境本身还大
- 同步方式更简单，debug 更容易

## cloud_launch.sh — 云端部署

支持 AWS / GCP / 阿里云，流程：

```
1. pip install -e .                     # 安装依赖
2. nvidia-smi                           # 检查 GPU
3. aws s3 sync / gsutil rsync / ossutil # 下载已有 checkpoint
4. python scripts/train_ppo.py ...      # 启动训练
5. aws s3 sync / gsutil rsync / ossutil # 上传结果
```

设计为 Spot 实例安全——定期保存 checkpoint，中断后可从 `checkpoints/latest.pt` 恢复。
