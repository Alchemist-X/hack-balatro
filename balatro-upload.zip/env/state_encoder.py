"""Encode pylatro GameState into fixed-size numeric tensors.

Since pylatro's Card objects don't expose rank/suit attributes to Python,
we construct the observation from:
  1. The action mask (79 dims) -- tells the agent what actions are legal
  2. Game state scalars -- score, required_score, plays, discards, money, etc.
  3. Count features -- num available cards, num selected, num jokers, deck size
  4. Stage encoding -- one-hot of the current game stage

Layout of the encoded vector
-----------------------------
  [action_mask (79) | stage_onehot (7) | scalar_features (12)]

Total dimension = 79 + 7 + 12 = 98
"""

from __future__ import annotations

import numpy as np


# ── Stage encoding ────────────────────────────────────────────────────

STAGE_NAMES = [
    "Stage_PreBlind",
    "Stage_Blind",
    "Stage_PostBlind",
    "Stage_Shop",
    "Stage_End",
    "Stage_CashOut",
    "Stage_Other",
]
NUM_STAGES = len(STAGE_NAMES)


def _stage_to_index(stage_type_name: str) -> int:
    """Map stage type name to an index for one-hot encoding."""
    for i, name in enumerate(STAGE_NAMES):
        if name in stage_type_name:
            return i
    return NUM_STAGES - 1  # "Other"


# ── Scalar normalization ─────────────────────────────────────────────

SCALAR_NORMS = {
    "score": 100_000.0,
    "required_score": 100_000.0,
    "score_ratio": 1.0,       # already a ratio
    "plays": 10.0,
    "discards": 10.0,
    "money": 100.0,
    "round": 10.0,
    "num_available": 24.0,
    "num_selected": 10.0,
    "num_jokers": 5.0,
    "num_deck": 60.0,
    "num_valid_actions": 79.0,
}
NUM_SCALARS = len(SCALAR_NORMS)
SCALAR_KEYS = list(SCALAR_NORMS.keys())

# Action mask size (from balatro-rs action space)
ACTION_MASK_SIZE = 79

# Total observation dimension
OBS_DIM = ACTION_MASK_SIZE + NUM_STAGES + NUM_SCALARS


# ── Main encoder ──────────────────────────────────────────────────────

class StateEncoder:
    """Encodes pylatro GameState into a flat float32 observation vector.

    The observation consists of:
    - action_mask (79): binary mask of valid actions
    - stage_onehot (7): one-hot encoding of game stage
    - scalar_features (12): normalized game state scalars
    """

    def __init__(self, config: dict | None = None):
        self._obs_dim = OBS_DIM

    @property
    def observation_dim(self) -> int:
        return self._obs_dim

    def encode_pylatro_state(self, state, action_mask: np.ndarray | None = None) -> np.ndarray:
        """Encode a pylatro GameState into a flat float32 vector.

        Parameters
        ----------
        state : pylatro GameState
            The current game state from ``engine.state``.
        action_mask : np.ndarray, optional
            Pre-computed action mask. If None, will be zeros.

        Returns
        -------
        np.ndarray of shape (observation_dim,)
        """
        obs = np.zeros(self._obs_dim, dtype=np.float32)
        offset = 0

        # 1. Action mask (79 dims)
        if action_mask is not None:
            obs[offset:offset + ACTION_MASK_SIZE] = action_mask.astype(np.float32)
        offset += ACTION_MASK_SIZE

        # 2. Stage one-hot (7 dims)
        stage_name = type(state.stage).__name__
        stage_idx = _stage_to_index(stage_name)
        obs[offset + stage_idx] = 1.0
        offset += NUM_STAGES

        # 3. Scalar features (12 dims)
        required = max(state.required_score, 1)
        scalars = {
            "score": float(state.score),
            "required_score": float(state.required_score),
            "score_ratio": float(state.score) / float(required),
            "plays": float(state.plays),
            "discards": float(state.discards),
            "money": float(state.money),
            "round": float(state.round),
            "num_available": float(len(state.available)),
            "num_selected": float(len(state.selected)),
            "num_jokers": float(len(state.jokers)),
            "num_deck": float(len(state.deck)),
            "num_valid_actions": float(action_mask.sum()) if action_mask is not None else 0.0,
        }

        for key in SCALAR_KEYS:
            norm = SCALAR_NORMS[key]
            obs[offset] = scalars[key] / norm
            offset += 1

        return obs

    def encode(self, obs, info: dict | None = None) -> np.ndarray:
        """Legacy encode method for compatibility.

        If obs is already a numpy array of the right shape, pass through.
        Otherwise try to interpret as a pylatro state.
        """
        if isinstance(obs, np.ndarray) and obs.shape == (self._obs_dim,):
            return obs
        # Fallback: return zeros
        return np.zeros(self._obs_dim, dtype=np.float32)
