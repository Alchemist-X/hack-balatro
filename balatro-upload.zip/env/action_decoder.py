"""Action decoder for pylatro-based environment.

Since pylatro provides a fixed-size action space (79 dimensions) with
a binary mask, the action decoder is trivially just index-based.

Action space layout (from balatro-rs/core/src/space.rs):
    0-23:  select card (24 slots)
    24-46: move card left (23 slots)
    47-69: move card right (23 slots)
    70:    play hand
    71:    discard
    72:    cash out
    73-76: buy joker (4 slots)
    77:    next round
    78:    select blind
"""

from __future__ import annotations

import numpy as np

# Action space constants
ACTION_SPACE_SIZE = 79

# Action type ranges
SELECT_CARD_START = 0
SELECT_CARD_END = 24
MOVE_LEFT_START = 24
MOVE_LEFT_END = 47
MOVE_RIGHT_START = 47
MOVE_RIGHT_END = 70
PLAY_IDX = 70
DISCARD_IDX = 71
CASHOUT_IDX = 72
BUY_JOKER_START = 73
BUY_JOKER_END = 77
NEXT_ROUND_IDX = 77
SELECT_BLIND_IDX = 78


def action_type(action_idx: int) -> str:
    """Return a human-readable action type string for an action index."""
    if SELECT_CARD_START <= action_idx < SELECT_CARD_END:
        return f"select_card_{action_idx}"
    elif MOVE_LEFT_START <= action_idx < MOVE_LEFT_END:
        return f"move_left_{action_idx - MOVE_LEFT_START}"
    elif MOVE_RIGHT_START <= action_idx < MOVE_RIGHT_END:
        return f"move_right_{action_idx - MOVE_RIGHT_START}"
    elif action_idx == PLAY_IDX:
        return "play"
    elif action_idx == DISCARD_IDX:
        return "discard"
    elif action_idx == CASHOUT_IDX:
        return "cashout"
    elif BUY_JOKER_START <= action_idx < BUY_JOKER_END:
        return f"buy_joker_{action_idx - BUY_JOKER_START}"
    elif action_idx == NEXT_ROUND_IDX:
        return "next_round"
    elif action_idx == SELECT_BLIND_IDX:
        return "select_blind"
    return f"unknown_{action_idx}"


def is_select_card(action_idx: int) -> bool:
    return SELECT_CARD_START <= action_idx < SELECT_CARD_END


def is_play(action_idx: int) -> bool:
    return action_idx == PLAY_IDX


def is_discard(action_idx: int) -> bool:
    return action_idx == DISCARD_IDX


def is_shop_action(action_idx: int) -> bool:
    return action_idx in (CASHOUT_IDX, NEXT_ROUND_IDX) or BUY_JOKER_START <= action_idx < BUY_JOKER_END


class ActionDecoder:
    """Minimal action decoder for the pylatro environment.

    Since pylatro uses ``handle_action_index(idx)`` directly,
    the decoder is just a thin utility layer.
    """

    def __init__(self, config: dict | None = None):
        self.action_space_size = ACTION_SPACE_SIZE

    @staticmethod
    def decode(action_idx: int, action_mask: np.ndarray) -> int:
        """Validate and return the action index.

        If the action is invalid per the mask, returns the first valid action.
        """
        if 0 <= action_idx < ACTION_SPACE_SIZE and action_mask[action_idx]:
            return action_idx

        # Fallback to first valid
        valid = np.where(action_mask)[0]
        if len(valid) > 0:
            return int(valid[0])
        return 0

    @staticmethod
    def get_valid_actions(action_mask: np.ndarray) -> list[int]:
        """Return list of valid action indices."""
        return list(np.where(action_mask)[0])

    @staticmethod
    def action_type(action_idx: int) -> str:
        return action_type(action_idx)
