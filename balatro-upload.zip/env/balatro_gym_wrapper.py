"""Gymnasium wrapper around pylatro (balatro-rs Python bindings).

Provides a standard Gymnasium interface for the Balatro game engine.
The action space is a fixed Discrete(79) with an action mask, matching
the layout defined in balatro-rs/core/src/space.rs:

    0-23:  select card (24 slots)
    24-46: move card left (23 slots)
    47-69: move card right (23 slots)
    70:    play hand
    71:    discard
    72:    cash out
    73-76: buy joker (4 slots)
    77:    next round
    78:    select blind
"""

from __future__ import annotations

from typing import Any

import gymnasium as gym
import numpy as np

from env.state_encoder import StateEncoder

# Action space size (fixed by balatro-rs)
ACTION_SPACE_SIZE = 79


class BalatroEnv(gym.Env):
    """Gymnasium environment wrapping pylatro GameEngine.

    Observation: flat float32 vector from StateEncoder.
    Action: integer in [0, 79), must be valid per action mask.
    """

    metadata = {"render_modes": ["human"]}

    def __init__(self, config: dict | None = None, render_mode: str | None = None):
        super().__init__()
        self.config = config or {}
        self.render_mode = render_mode

        self.state_encoder = StateEncoder(config=self.config.get("observation", {}))

        # Spaces
        obs_dim = self.state_encoder.observation_dim
        self.observation_space = gym.spaces.Box(
            low=-np.inf, high=np.inf, shape=(obs_dim,), dtype=np.float32
        )
        self.action_space = gym.spaces.Discrete(ACTION_SPACE_SIZE)

        # Game engine (created on reset)
        self._engine = None
        self._step_count = 0
        self._prev_score = 0
        self._blinds_passed = 0

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        """Reset the environment and start a new game."""
        super().reset(seed=seed)

        from pylatro import GameEngine
        self._engine = GameEngine()
        self._step_count = 0
        self._prev_score = 0
        self._blinds_passed = 0

        obs = self._get_obs()
        info = self._get_info()
        return obs, info

    def step(self, action: int):
        """Execute an action and return (obs, reward, terminated, truncated, info)."""
        assert self._engine is not None, "Must call reset() before step()"

        # Get action mask and validate
        mask = self.get_action_mask()
        if not mask[action]:
            # Invalid action: pick first valid action as fallback
            valid = np.where(mask)[0]
            if len(valid) > 0:
                action = int(valid[0])
            else:
                # No valid actions — game should be over
                obs = self._get_obs()
                info = self._get_info()
                return obs, 0.0, True, False, info

        # Execute action
        try:
            self._engine.handle_action_index(action)
        except Exception:
            # Engine error — treat as terminal
            obs = self._get_obs()
            info = self._get_info()
            return obs, -1.0, True, False, info

        self._step_count += 1

        # Compute reward
        state = self._engine.state
        reward = self._compute_reward(state)
        self._prev_score = state.score

        # Check termination
        terminated = self._engine.is_over
        truncated = self._step_count >= 2000  # Safety limit

        # Track blind passes (score resets when blind is passed)
        stage_name = type(state.stage).__name__
        if "PostBlind" in stage_name or "Shop" in stage_name:
            if state.score == 0 and self._prev_score > 0:
                self._blinds_passed += 1

        obs = self._get_obs()
        info = self._get_info()

        if self.render_mode == "human" and self._step_count % 10 == 0:
            self._render_human()

        return obs, reward, terminated, truncated, info

    def get_action_mask(self) -> np.ndarray:
        """Return boolean mask of valid actions. True = valid."""
        if self._engine is None:
            return np.zeros(ACTION_SPACE_SIZE, dtype=bool)
        space = self._engine.gen_action_space()
        return np.array(space, dtype=bool)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_obs(self) -> np.ndarray:
        """Encode the current game state as a flat observation vector."""
        if self._engine is None:
            return np.zeros(self.state_encoder.observation_dim, dtype=np.float32)
        state = self._engine.state
        mask = self.get_action_mask()
        return self.state_encoder.encode_pylatro_state(state, action_mask=mask)

    def _get_info(self) -> dict:
        """Build the info dict."""
        if self._engine is None:
            return {}
        state = self._engine.state
        stage_name = type(state.stage).__name__
        return {
            "stage": stage_name,
            "score": state.score,
            "required_score": state.required_score,
            "plays": state.plays,
            "discards": state.discards,
            "money": state.money,
            "round": state.round,
            "num_available": len(state.available),
            "num_selected": len(state.selected),
            "num_jokers": len(state.jokers),
            "num_deck": len(state.deck),
            "step_count": self._step_count,
            "blinds_passed": self._blinds_passed,
            "game_won": self._engine.is_win if self._engine.is_over else False,
            "is_over": self._engine.is_over,
        }

    def _compute_reward(self, state) -> float:
        """Compute shaped reward."""
        reward_cfg = self.config.get("reward", {})
        reward = 0.0

        # Score progress reward
        score_delta = state.score - self._prev_score
        if score_delta > 0 and state.required_score > 0:
            scale = reward_cfg.get("score_shaping_scale", 0.1)
            reward += scale * np.log1p(score_delta / state.required_score)

        # Win reward
        if self._engine.is_over:
            if self._engine.is_win:
                reward += reward_cfg.get("win_reward", 10.0)
            # No extra penalty for losing (sparse enough)

        # Blind pass detection (heuristic: stage transitions)
        stage_name = type(state.stage).__name__
        if "PostBlind" in stage_name:
            reward += reward_cfg.get("blind_pass_reward", 0.5)

        return float(reward)

    def _render_human(self):
        """Print game state for human observation."""
        state = self._engine.state
        stage = type(state.stage).__name__
        mask = self.get_action_mask()
        print(
            f"  Step {self._step_count:4d} | {stage:20s} | "
            f"Score: {state.score:6d}/{state.required_score:6d} | "
            f"Plays: {state.plays} Disc: {state.discards} | "
            f"Money: {state.money:3d} | "
            f"Cards: {len(state.available):2d} Sel: {len(state.selected):2d} | "
            f"Valid: {mask.sum():2d}"
        )


# ---------------------------------------------------------------------------
# Factory functions
# ---------------------------------------------------------------------------

def make_env(config: dict | None = None, seed: int | None = None) -> BalatroEnv:
    """Create a single Balatro environment."""
    env = BalatroEnv(config=config)
    if seed is not None:
        env.reset(seed=seed)
    return env


def make_vec_env(
    config: dict | None = None,
    num_envs: int | None = None,
    seed: int = 0,
) -> gym.vector.VectorEnv:
    """Create a vectorized set of Balatro environments."""
    config = config or {}
    if num_envs is None:
        num_envs = config.get("environment", {}).get("num_envs", 16)

    def _make_fn(i: int):
        def _init():
            return BalatroEnv(config=config)
        return _init

    envs = gym.vector.AsyncVectorEnv(
        [_make_fn(i) for i in range(num_envs)]
    )
    return envs
