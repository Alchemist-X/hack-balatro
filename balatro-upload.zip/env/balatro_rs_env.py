"""Placeholder for high-performance Rust-backed Balatro environment.

This module will eventually wrap evanofslack/balatro-rs via PyO3 Python
bindings (the ``pylatro`` package) to provide much faster simulation
throughput than the pure-Python balatro-gym.

TODO:
  - Install pylatro (pip install pylatro or build from source)
  - Implement BalatroRsEnv conforming to the same interface as
    BalatroEnvWrapper so it can be swapped in via config
  - Benchmark throughput vs balatro-gym
"""

from __future__ import annotations

import gymnasium as gym
import numpy as np


class BalatroRsEnv(gym.Env):
    """Rust-backed Balatro environment (NOT YET IMPLEMENTED).

    See: https://github.com/evanofslack/balatro-rs
    """

    metadata = {"render_modes": []}

    def __init__(self, config: dict | None = None):
        raise NotImplementedError(
            "BalatroRsEnv is not yet implemented. "
            "Install pylatro and implement this wrapper to use the Rust backend. "
            "See https://github.com/evanofslack/balatro-rs for details."
        )

    def reset(self, *, seed=None, options=None):
        raise NotImplementedError

    def step(self, action):
        raise NotImplementedError
